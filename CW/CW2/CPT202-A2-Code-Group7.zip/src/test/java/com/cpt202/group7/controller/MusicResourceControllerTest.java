package com.cpt202.group7.controller;

import com.cpt202.group7.model.Category;
import com.cpt202.group7.model.MusicResource;
import com.cpt202.group7.model.Tag;
import com.cpt202.group7.model.User;
import com.cpt202.group7.repository.CategoryRepo;
import com.cpt202.group7.repository.MusicResourceRepo;
import com.cpt202.group7.repository.TagRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.ui.Model;

import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MusicResourceControllerTest {

    @InjectMocks
    private MusicResourceController musicResourceController;

    @Mock
    private MusicResourceRepo musicResourceRepo;

    @Mock
    private CategoryRepo categoryRepo;

    @Mock
    private TagRepo tagRepo;

    @Mock
    private Model model;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }


    @Test
    void testEditMusicResource() {
        Integer musicResourceId = 1;
        Integer categoryId = 2;
        MusicResource musicResource = new MusicResource();
        musicResource.setId(musicResourceId);

        Category category = new Category();
        category.setId(categoryId);
        category.setVolume(1);

        User user = new User();
        user.setId(1);
        MockHttpSession mockSession = new MockHttpSession();
        mockSession.setAttribute("loginUser", user);

        when(musicResourceRepo.findByUserAndIdAndStatus(user, musicResourceId, 0)).thenReturn(musicResource);
        when(categoryRepo.findByUserAndIdAndStatus(user, categoryId, 0)).thenReturn(category); // Simulate category found
        when(tagRepo.findByUserAndStatusAndIdIn(user, 0, Collections.emptyList())).thenReturn(Collections.emptyList());

        String result = musicResourceController.editMusicResource(musicResourceId, categoryId, Collections.emptyList(), mockSession, model);

        verify(musicResourceRepo).save(musicResource);
        assertEquals("redirect:/", result);
    }
}
