package com.cpt202.group7.controller;

import com.cpt202.group7.model.Category;
import com.cpt202.group7.model.MusicResource;
import com.cpt202.group7.model.User;
import com.cpt202.group7.repository.CategoryRepo;
import com.cpt202.group7.repository.MusicResourceRepo;
import jakarta.servlet.http.HttpSession;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.InternalResourceView;
import org.springframework.web.servlet.view.RedirectView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class CategoryControllerTest {

    private MockMvc mockMvc;

    @InjectMocks
    private CategoryController categoryController;

    @Mock
    private CategoryRepo categoryRepo;

    @Mock
    private MusicResourceRepo musicResourceRepo;

    @Mock
    private HttpSession session;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // 处理普通页面和redirect:页面的ViewResolver
        ViewResolver viewResolver = (viewName, locale) -> {
            if (viewName.startsWith("redirect:")) {
                return new RedirectView(viewName.substring(9));
            }
            return new InternalResourceView("/WEB-INF/views/" + viewName + ".jsp");
        };

        mockMvc = MockMvcBuilders
                .standaloneSetup(categoryController)
                .setViewResolvers(viewResolver)
                .build();
    }

    @Test
    void testGetAllCategories() throws Exception {
        User mockUser = new User();
        mockUser.setAvatar("mock-avatar.png");
        when(session.getAttribute("loginUser")).thenReturn(mockUser);

        mockMvc.perform(get("/category").sessionAttr("loginUser", mockUser))
                .andExpect(status().isOk())
                .andExpect(view().name("category2"));
    }

    @Test
    void testAddCategory() throws Exception {
        User mockUser = new User();
        when(session.getAttribute("loginUser")).thenReturn(mockUser);

        mockMvc.perform(post("/category/add")
                        .sessionAttr("loginUser", mockUser)
                        .param("name", "New Category"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/category"));

        verify(categoryRepo, times(1)).save(any(Category.class));
    }

    @Test
    void testEditCategory() throws Exception {
        Category existingCategory = new Category();
        existingCategory.setId(1);
        existingCategory.setName("Old Name");

        User user = new User();
        user.setId(1);
        MockHttpSession mockSession = new MockHttpSession();
        mockSession.setAttribute("loginUser", user);

        when(categoryRepo.findByUserAndIdAndStatus(user, 1, 0)).thenReturn(existingCategory);

        mockMvc.perform(post("/category/edit")
                        .param("id", "1")
                        .param("name", "Updated Name")
                        .session(mockSession))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/category"));

        verify(categoryRepo, times(1)).save(existingCategory);
    }

    @Test
    void testDeleteCategory() throws Exception {
        Category existingCategory = new Category();
        existingCategory.setId(1);
        existingCategory.setStatus(0);

        MusicResource musicResource = new MusicResource();
        musicResource.setStatus(0);
        musicResource.setCategory(existingCategory);

        List<MusicResource> musicResources = new ArrayList<>();
        musicResources.add(musicResource);

        User user = new User();
        user.setId(1);
        MockHttpSession mockSession = new MockHttpSession();
        mockSession.setAttribute("loginUser", user);

        when(categoryRepo.findByUserAndIdAndStatus(user, 1, 0)).thenReturn(existingCategory);
        when(musicResourceRepo.findByUserAndStatusAndCategory(user, 0, existingCategory)).thenReturn(musicResources);

        mockMvc.perform(post("/category/delete")
                        .param("id", "1")
                        .session(mockSession))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/category"));

        verify(categoryRepo, times(1)).save(existingCategory);
    }
}
