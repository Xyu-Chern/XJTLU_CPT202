package com.cpt202.group7.service.impl;

import com.cpt202.group7.model.SecureToken;
import com.cpt202.group7.repository.SecureTokenRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDateTime;
import java.util.Base64;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SecureTokenServiceImplTest {

    @Mock
    private SecureTokenRepo secureTokenRepo;

    @InjectMocks
    private SecureTokenServiceImpl secureTokenService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateToken() {
        // Act
        SecureToken token = secureTokenService.createToken();

        // Assert
        assertNotNull(token, "Token should not be null");
        assertNotNull(token.getToken(), "Token value should not be null");
        assertNotNull(token.getExpiredDate(), "Token expiration date should not be null");
        assertTrue(token.getExpiredDate().isAfter(LocalDateTime.now()), "Token expiration date should be in the future");

        // Verify token format (Base64 URL-safe)
        assertTrue(Base64.getUrlDecoder().decode(token.getToken()).length > 0, "Token should be valid Base64");
    }

    @Test
    void testSaveSecureToken() {
        // Arrange
        SecureToken token = new SecureToken();

        // Act
        secureTokenService.saveSecureToken(token);

        // Assert
        verify(secureTokenRepo, times(1)).save(token);
    }

    @Test
    void testFindByToken() {
        // Arrange
        String tokenValue = "testToken";
        SecureToken token = new SecureToken();
        when(secureTokenRepo.findByToken(tokenValue)).thenReturn(token);

        // Act
        SecureToken result = secureTokenService.findByToken(tokenValue);

        // Assert
        assertNotNull(result);
        assertEquals(token, result);
        verify(secureTokenRepo, times(1)).findByToken(tokenValue);
    }


    @Test
    void testRemoveToken() {
        // Arrange
        SecureToken token = new SecureToken();

        // Act
        secureTokenService.removeToken(token);

        // Assert
        verify(secureTokenRepo, times(1)).delete(token);
    }

    @Test
    void testFindByTokenAndUserId_NoTokens() {
        // Arrange
        Integer userId = 1;
        String code = "1234";
        when(secureTokenRepo.findByUserId(userId)).thenReturn(Collections.emptyList());

        // Act
        SecureToken result = secureTokenService.findByTokenAndUserId(userId, code);

        // Assert
        assertNull(result);
        verify(secureTokenRepo, times(1)).findByUserId(userId);
    }

    @Test
    void testFindByTokenAndUserId_MatchingToken() {
        // Arrange
        Integer userId = 1;
        String code = "1234";
        SecureToken token = new SecureToken();
        token.setToken(code);
        token.setUsed(false);
        when(secureTokenRepo.findByUserId(userId)).thenReturn(List.of(token));

        // Act
        SecureToken result = secureTokenService.findByTokenAndUserId(userId, code);

        // Assert
        assertNotNull(result);
        assertEquals(token, result);
        verify(secureTokenRepo, times(1)).findByUserId(userId);
    }

    @Test
    void testFindByTokenAndUserId_NoMatchingToken() {
        // Arrange
        Integer userId = 1;
        String code = "1234";
        SecureToken token = new SecureToken();
        token.setToken("5678");
        token.setUsed(false);
        when(secureTokenRepo.findByUserId(userId)).thenReturn(List.of(token));

        // Act
        SecureToken result = secureTokenService.findByTokenAndUserId(userId, code);

        // Assert
        assertNull(result);
        verify(secureTokenRepo, times(1)).findByUserId(userId);
    }
}