package com.cpt202.group7.service.impl;

import com.cpt202.group7.exception.InvalidTokenException;
import com.cpt202.group7.exception.UserAlreadyActivatedException;
import com.cpt202.group7.model.SecureToken;
import com.cpt202.group7.model.User;
import com.cpt202.group7.repository.UserRepo;
import com.cpt202.group7.service.SecureTokenService;
import com.cpt202.group7.util.AbstractEmailContext;
import jakarta.mail.MessagingException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class UserServiceImplTest {

    @Mock
    private UserRepo userRepo;

    @Mock
    private EmailServiceImpl emailService;

    @Mock
    private SecureTokenService secureTokenService;

    @InjectMocks
    private UserServiceImpl userService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testRegister() throws MessagingException, IOException {
        // Arrange
        User user = new User();
        user.setEmail("test@example.com");
        user.setPassword("password");

        MultipartFile avatarFile = mock(MultipartFile.class);
        when(avatarFile.getOriginalFilename()).thenReturn("test_avatar.jpg");
        when(avatarFile.isEmpty()).thenReturn(false);

        // Use a valid temporary directory
        String tempDir = System.getProperty("java.io.tmpdir") + "/img";
        System.setProperty("user.dir", tempDir);

        // Mock the file transfer
        doAnswer(invocation -> {
            File destinationFile = invocation.getArgument(0);
            assertTrue(destinationFile.getName().startsWith("avatar_1_"));
            assertTrue(destinationFile.getName().endsWith(".jpg"));
            return null;
        }).when(avatarFile).transferTo(any(File.class));

        when(userRepo.save(any(User.class))).thenAnswer(invocation -> {
            User savedUser = invocation.getArgument(0);
            savedUser.setId(1); // Simulate the database assigning an ID
            return savedUser;
        });

        SecureToken secureToken = new SecureToken();
        secureToken.setToken("mockToken");
        when(secureTokenService.createToken()).thenReturn(secureToken);
        doNothing().when(secureTokenService).saveSecureToken(secureToken);

        // Mock the baseUrl property
        ReflectionTestUtils.setField(userService, "baseUrl", "http://localhost:8080");

        // Act
        userService.register(user, avatarFile);

        // Assert
        verify(userRepo, times(2)).save(user); // Expect two saves
        verify(secureTokenService, times(1)).saveSecureToken(secureToken);
        verify(emailService, times(1)).sendMail(any(AbstractEmailContext.class));

        // Cleanup
        File directory = new File(tempDir);
        if (directory.exists()) {
            for (File file : directory.listFiles()) {
                file.delete();
            }
            directory.delete();
        }
    }

    @Test
    void testUploadAvatarFile() throws IOException {
        // Arrange
        User user = new User();
        user.setId(1);

        MultipartFile avatarFile = mock(MultipartFile.class);
        when(avatarFile.getOriginalFilename()).thenReturn("test_avatar.jpg");
        when(avatarFile.isEmpty()).thenReturn(false);

        // Use a valid temporary directory
        String tempDir = System.getProperty("java.io.tmpdir") + "/img";
        System.setProperty("user.dir", tempDir);

        // Mock the file transfer
        doAnswer(invocation -> {
            File destinationFile = invocation.getArgument(0);
            assertTrue(destinationFile.getName().startsWith("avatar_1_"));
            assertTrue(destinationFile.getName().endsWith(".jpg"));
            return null;
        }).when(avatarFile).transferTo(any(File.class));

        // Act
        userService.uploadAvatarFile(user, avatarFile);

        // Assert
        assertNotNull(user.getAvatar());
        assertTrue(user.getAvatar().startsWith("avatar_1_"));
        assertTrue(user.getAvatar().endsWith(".jpg"));

        // Cleanup (optional)
        File directory = new File(tempDir);
        if (directory.exists()) {
            for (File file : directory.listFiles()) {
                file.delete();
            }
            directory.delete();
        }
    }

    @Test
    void testUploadAvatarFile_FileSaveFailure() throws IOException {
        // Arrange
        User user = new User();
        user.setId(1);

        MultipartFile avatarFile = mock(MultipartFile.class);
        when(avatarFile.getOriginalFilename()).thenReturn("test_avatar.jpg");
        when(avatarFile.isEmpty()).thenReturn(false);

        // Mock file transfer failure
        doThrow(new IOException("File save failed")).when(avatarFile).transferTo(any(File.class));

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            userService.uploadAvatarFile(user, avatarFile);
        });
        assertTrue(exception.getMessage().contains("Failed to save avatar file"));
    }

    @Test
    void testSendRegistrationConfirmationEmail() throws MessagingException {
        // Arrange
        User user = new User();
        user.setEmail("test@example.com");

        SecureToken secureToken = new SecureToken();
        secureToken.setToken("mockToken");

        when(secureTokenService.createToken()).thenReturn(secureToken);
        doNothing().when(secureTokenService).saveSecureToken(secureToken);

        // Mock the baseUrl property
        ReflectionTestUtils.setField(userService, "baseUrl", "http://localhost:8080");

        // Act
        userService.sendRegistrationConfirmationEmail(user);

        // Verify
        verify(secureTokenService, times(1)).saveSecureToken(secureToken);
        verify(emailService, times(1)).sendMail(any(AbstractEmailContext.class));
    }

    @Test
    void testVerifyUser() throws InvalidTokenException, UserAlreadyActivatedException {
        // Arrange
        String token = "validToken";
        SecureToken secureToken = new SecureToken();
        secureToken.setToken(token);
        secureToken.setUsed(false);
        secureToken.setExpiredDate(LocalDateTime.now().plusMinutes(30)); // Set a valid expiration date

        User user = new User();
        user.setId(1);
        user.setStatus(1); // Not activated

        secureToken.setUser(user);

        when(secureTokenService.findByToken(token)).thenReturn(secureToken);
        when(userRepo.findById(user.getId())).thenReturn(Optional.of(user));

        // Act
        boolean result = userService.verifyUser(token);

        // Assert
        assertTrue(result);
    }
}
