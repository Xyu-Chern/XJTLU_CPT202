// AdminControllerTest.java
package com.cpt202.group7.controller;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.cpt202.group7.model.MusicResource;
import com.cpt202.group7.model.User;
import com.cpt202.group7.repository.MusicResourceRepo;
import com.cpt202.group7.repository.UserRepo;
import com.cpt202.group7.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.Model;
import org.springframework.web.servlet.view.RedirectView;

import java.util.Collections;
import java.util.Optional;

class AdminControllerTest {

    private MockMvc mockMvc;
    private MockHttpSession mockSession;

    @Mock
    private UserRepo userRepo;

    @Mock
    private MusicResourceRepo musicResourceRepo;

    @Mock
    private UserService userService;

    @Mock
    private Model model;

    @InjectMocks
    private AdminController adminController;

    private User adminUser;
    private User normalUser;
    private MusicResource pendingMusic;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(adminController).build();
        mockSession = new MockHttpSession();

        // 初始化测试用户
        adminUser = new User();
        adminUser.setId(1);
        adminUser.setRole(0);  // 管理员
        adminUser.setStatus(0);

        normalUser = new User();
        normalUser.setId(2);
        normalUser.setRole(1);  // 普通用户
        normalUser.setStatus(0);

        // 初始化测试音乐资源
        pendingMusic = new MusicResource();
        pendingMusic.setId(1);
        pendingMusic.setStatus(1);
    }

    // 测试管理员主页访问
    @Test
    void getAdminPage_AdminUser_ReturnsAuditPage() {
        mockSession.setAttribute("loginUser", adminUser);
        String viewName = adminController.getAdminPage(mockSession, model);
        assertThat(viewName).isEqualTo("redirect:/admin/audit");
    }

    @Test
    void getAdminPage_NonAdminUser_RedirectToLogin() {
        mockSession.setAttribute("loginUser", normalUser);
        String viewName = adminController.getAdminPage(mockSession, model);
        assertThat(viewName).isEqualTo("redirect:/login");
    }

    // 测试用户管理页面
    @Test
    void users_AdminUser_ReturnsUsersPage() {
        mockSession.setAttribute("loginUser", adminUser);
        when(userRepo.findByRoleAndStatus(1,0)).thenReturn(Collections.singletonList(normalUser));

        String viewName = adminController.users(mockSession, 0, model);
        verify(model).addAttribute("avatar", adminUser.getAvatar());
        verify(model).addAttribute("users", Collections.singletonList(normalUser));
        assertThat(viewName).isEqualTo("users");
    }

    // 测试锁定用户功能
    @Test
    void lockUser_AdminLockNormalUser_UpdatesStatus() throws Exception {
        mockSession.setAttribute("loginUser", adminUser);
        when(userRepo.findFirstById(2)).thenReturn(normalUser);

        mockMvc.perform(post("/admin/users/lock")
                        .param("userId", "2")
                        .session(mockSession))
                .andExpect(status().is3xxRedirection())
                .andExpect(view().name("redirect:/admin/users"));

        verify(userRepo).save(normalUser);
        assertThat(normalUser.getStatus()).isEqualTo(2);
    }

    @Test
    void lockUser_AdminLockAdmin() throws Exception {
        User anotherAdmin = new User();
        anotherAdmin.setId(3);
        anotherAdmin.setRole(0);
        mockSession.setAttribute("loginUser", adminUser);
        when(userRepo.findFirstById(3)).thenReturn(anotherAdmin);

        mockMvc.perform(post("/admin/users/lock")
                        .param("userId", "3")
                        .session(mockSession))
                .andExpect(view().name("redirect:/admin/users"));

        verify(userRepo, never()).save(any());
    }

    // 测试个人资料更新
    @Test
    void updateProfile_ValidUpdate_UpdatesUser() {
        User updatedUser = new User();
        updatedUser.setId(1);
        updatedUser.setEmail("new@example.com");
        updatedUser.setAvatar("new-avatar.jpg");
        updatedUser.setRole(0);

        mockSession.setAttribute("loginUser", adminUser);
        when(userService.getUserById(1)).thenReturn(adminUser);

        String result = adminController.updateProfile(updatedUser, mockSession);
        verify(userService).updateUserInfo(eq(1), any(User.class));
        assertThat(result).isEqualTo("redirect:/admin/profile");
    }

    // 测试文件下载功能
    @Test
    void viewFile_ValidRequest_ReturnsFile() throws Exception {
        mockMvc.perform(get("/admin/view/uploads/test.jpg"))
                .andExpect(status().isOk())
                .andExpect(header().exists("Content-Disposition"));
    }
}
