package com.cpt202.group7.controller;

import com.cpt202.group7.model.User;
import jakarta.servlet.http.HttpSession;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.InternalResourceView;
import org.springframework.web.servlet.view.RedirectView;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class FeedbackControllerTest {

    private MockMvc mockMvc;

    @InjectMocks
    private FeedbackController feedbackController;

    @Mock
    private HttpSession session;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // ViewResolver：处理普通页面 + redirect
        ViewResolver viewResolver = (viewName, locale) -> {
            if (viewName.startsWith("redirect:")) {
                return new RedirectView(viewName.substring(9));
            }
            return new InternalResourceView("/WEB-INF/views/" + viewName + ".jsp");
        };

        mockMvc = MockMvcBuilders
                .standaloneSetup(feedbackController)
                .setViewResolvers(viewResolver)
                .build();
    }

    @Test
    void testGetFeedbackPage_UserRoleIs0_ShouldReturnAdminPage() throws Exception {
        User user = new User();
        user.setRole(0); // 普通用户

        when(session.getAttribute("loginUser")).thenReturn(user);

        mockMvc.perform(get("/feedback").sessionAttr("loginUser", user))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/admin/profile"));
    }

    @Test
    void testGetFeedbackPage_UserRoleIsNot0_ShouldReturnFeedbackPage() throws Exception {
        User user = new User();
        user.setRole(1); // 普通用户

        when(session.getAttribute("loginUser")).thenReturn(user);

        mockMvc.perform(get("/feedback").sessionAttr("loginUser", user))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/profile"));
    }

    @Test
    void testPostFeedback_UserRoleIs0_ShouldRedirectToProfile() throws Exception {
        User user = new User();
        user.setRole(0);

        when(session.getAttribute("loginUser")).thenReturn(user);

        mockMvc.perform(post("/feedback")
                        .sessionAttr("loginUser", user)
                        .param("feedback", "test feedback"))
                .andExpect(status().isOk())
                .andExpect(view().name("profileAdminPage"));
    }

    @Test
    void testPostFeedback_UserRoleIsNot0_ShouldReturnToProfile() throws Exception {
        User user = new User();
        user.setRole(1);

        when(session.getAttribute("loginUser")).thenReturn(user);

        mockMvc.perform(post("/feedback")
                        .sessionAttr("loginUser", user)
                        .param("feedback", "some feedback"))
                .andExpect(status().isOk())
                .andExpect(view().name("profilePage"));
    }
}
