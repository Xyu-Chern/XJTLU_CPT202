package com.cpt202.group7.controller;

import com.cpt202.group7.model.User;
import com.cpt202.group7.service.UserService;
import com.cpt202.group7.service.EmailService;
import com.cpt202.group7.repository.UserRepo;
import com.cpt202.group7.util.AccountVerificationEmailContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
public class UserUpdateProfileControllerTest {

    @InjectMocks
    private UserUpdateProfileController userUpdateProfileController;

    @Mock
    private UserRepo userRepo;

    @Mock
    private UserService userService;

    @Mock
    private EmailService emailService;

    private MockMvc mockMvc;

    @BeforeEach
    public void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(userUpdateProfileController).build();  // Setup MockMvc for testing
    }


    @Test
    public void testShowUpdateForm_Success() throws Exception {
        // Prepare mock user data
        User mockUser = new User();
        mockUser.setId(1);
        mockUser.setEmail("test@example.com");
        mockUser.setAvatar("avatar.jpg");

        // Mock the repository to return the user
        when(userRepo.findById(1)).thenReturn(java.util.Optional.of(mockUser));

        // Perform the GET request
        mockMvc.perform(MockMvcRequestBuilders.get("/updateProfileForm")
                        .param("userId", "1"))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("updateProfile"))  // Check the view name
                .andExpect(MockMvcResultMatchers.model().attribute("user", mockUser));  // Verify the user model attribute
    }

    @Test
    public void testSendVerificationEmail_Success() throws Exception {
        // Prepare mock user data
        User mockUser = new User();
        mockUser.setEmail("test@example.com");

        // Perform the POST request
        mockMvc.perform(MockMvcRequestBuilders.post("/sendVerificationEmail")
                        .contentType("application/json")
                        .content("{\"email\":\"test@example.com\"}"))
                .andExpect(status().isOk())  // Expect HTTP 200 OK
                .andExpect(MockMvcResultMatchers.jsonPath("$.ok").value(true));  // Expect success response

        // Verify that the sendCodeConfirmationEmail method was called
        verify(userService, times(1)).sendCodeConfirmationEmail(mockUser);
    }

    @Test
    public void testUpdatePwd_Success() throws Exception {
        // Prepare mock user data
        User mockUser = new User();
        mockUser.setEmail("test@example.com");

        // Perform the POST request to update password
        mockMvc.perform(MockMvcRequestBuilders.post("/updatePwd")
                        .contentType("application/json")
                        .content("{\"email\":\"test@example.com\"}")
                        .param("newPassword", "validCode"))
                .andExpect(status().is3xxRedirection())  // Expect HTTP 200 OK
                .andExpect(redirectedUrl("/login"));

        // Verify that the updatePwd method was called
        verify(userService, times(1)).updatePwd(mockUser, "validCode");
    }

    @Test
    public void testUpdateProfileFromUpdateController_Success() throws Exception {
        // Prepare mock user data
        User mockUser = new User();
        mockUser.setId(1);
        mockUser.setEmail("oldemail@example.com");
        mockUser.setAvatar("oldavatar.jpg");

        // Mock the service to return the user
        when(userService.getUserById(1)).thenReturn(mockUser);

        // Perform the POST request to update the profile
        mockMvc.perform(MockMvcRequestBuilders.post("/updateProfileForm")
                        .param("userId", "1")
                        .param("email", "newemail@example.com")
                        .param("avatar", "newavatar.jpg"))
                .andExpect(status().is3xxRedirection())  // Expect a redirection
                .andExpect(MockMvcResultMatchers.redirectedUrl("/updateProfileSuccessPage"));  // Expect redirection to success page

        // Verify that the updateUserInfo method was called
        verify(userService, times(1)).updateUserInfo(eq(1), any(User.class));
    }

    @Test
    public void testConfirmUpdate_Success() throws Exception {
        // Prepare a valid token
        String validToken = "validToken";

        // Mock the service to verify the token
        when(userService.verifyUser(validToken)).thenReturn(true);

        // Perform the GET request
        mockMvc.perform(MockMvcRequestBuilders.get("/confirm-update")
                        .param("token", validToken))
                .andExpect(status().isFound())  // Expect HTTP 302 Redirect
                .andExpect(MockMvcResultMatchers.redirectedUrl("/updateProfileSuccessPage"));  // Expect redirection to success page
    }
}
