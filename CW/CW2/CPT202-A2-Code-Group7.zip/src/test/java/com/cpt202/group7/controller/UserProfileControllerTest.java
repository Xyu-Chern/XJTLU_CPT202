package com.cpt202.group7.controller;

import com.cpt202.group7.model.User;
import com.cpt202.group7.service.UserService;
import com.cpt202.group7.repository.UserRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
public class UserProfileControllerTest {

    @InjectMocks
    private UserProfileController userProfileController;

    @Mock
    private UserRepo userRepo;

    @Mock
    private UserService userService;

    private MockMvc mockMvc;

    @BeforeEach
    public void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(userProfileController).build();
    }

    @Test
    public void testViewProfile_Success() throws Exception {
        // Prepare test data
        User mockUser = new User();
        mockUser.setId(1);
        mockUser.setEmail("test@example.com");
        mockUser.setAvatar("avatar.jpg");

        // Mock session
        MockHttpSession mockSession = new MockHttpSession();
        mockSession.setAttribute("loginUser", mockUser);

        mockMvc.perform(MockMvcRequestBuilders.get("/profile")
                        .session(mockSession))
                .andExpect(status().isOk())  // Expect HTTP 200 OK
                .andExpect(view().name("profilePage"))  // View should be "viewProfile"
                .andExpect(model().attribute("user", mockUser));  // User data should be added to the model
    }

    @Test
    public void testUpdateProfile_IncorrectPassword() throws Exception {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(12);
        String passwordPattern = "^(?=.*[0-9])(?=.*[!@#$%^&*])[A-Za-z0-9!@#$%^&*]{8,}$";

        // Prepare test data
        User mockUser = new User();
        mockUser.setId(1);
        mockUser.setEmail("newemail@example.com");
        mockUser.setAvatar("newavatar.jpg");
        mockUser.setRole(1);
        mockUser.setPassword(encoder.encode("!12345678"));
        userRepo.save(mockUser);
        MockHttpSession mockSession = new MockHttpSession();
        mockSession.setAttribute("loginUser", mockUser);

        when(userRepo.findFirstById(mockUser.getId())).thenReturn(mockUser);

        // Simulate profile update with valid JSON data
        mockMvc.perform(post("/profile/update")
                        .param("id", "1")
                        .param("name", "123")
                        .param("email", "newemail@example.com")
                        .param("avatar", "newavatar.jpg")
                        .param("currentPassword", "invalidPassword")
                        .param("newPassword", "!123validPassword")
                        .param("confirmPassword", "!123validPassword")
                        .session(mockSession))
                .andExpect(status().isOk())  // Expect redirection after update
                .andExpect(view().name("profilePage"));
    }

    @Test
    public void testUpdateProfile_CorrectPassword() throws Exception {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(12);
        String passwordPattern = "^(?=.*[0-9])(?=.*[!@#$%^&*])[A-Za-z0-9!@#$%^&*]{8,}$";

        // Prepare test data
        User mockUser = new User();
        mockUser.setId(1);
        mockUser.setEmail("newemail@example.com");
        mockUser.setAvatar("newavatar.jpg");
        mockUser.setRole(1);
        mockUser.setPassword(encoder.encode("!12345678"));
        userRepo.save(mockUser);
        MockHttpSession mockSession = new MockHttpSession();
        mockSession.setAttribute("loginUser", mockUser);

        when(userRepo.findFirstById(mockUser.getId())).thenReturn(mockUser);

        // Simulate profile update with valid JSON data
        mockMvc.perform(post("/profile/update")
                        .param("id", "1")
                        .param("name", "123")
                        .param("email", "newemail@example.com")
                        .param("avatar", "newavatar.jpg")
                        .param("currentPassword", "!12345678")
                        .param("newPassword", "!123validPassword")
                        .param("confirmPassword", "!123validPassword")
                        .session(mockSession))
                .andExpect(status().is3xxRedirection())  // Expect redirection after update
                .andExpect(redirectedUrl("/login"));
    }

    @Test
    public void testDownloadFile_Success() throws Exception {
        // Simulate file download request
        mockMvc.perform(MockMvcRequestBuilders.get("/view/uploads/avatar.jpg"))
                .andExpect(status().isOk())  // Expect HTTP 200 OK
                .andExpect(header().string("Content-Disposition", "attachment;fileName=avatar.jpg"))  // Check the content-disposition header
                .andExpect(content().contentType("application/force-download"));  // Check the content type
    }
}
