package com.cpt202.group7.controller;

import com.cpt202.group7.model.User;
import com.cpt202.group7.repository.CategoryRepo;
import com.cpt202.group7.repository.MusicResourceRepo;
import com.cpt202.group7.repository.TagRepo;
import jakarta.servlet.http.HttpSession;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.InternalResourceView;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

class BaseControllerTest {

    private MockMvc mockMvc;

    @InjectMocks
    private BaseController baseController;

    @Mock
    private MusicResourceRepo musicResourceRepo;

    @Mock
    private CategoryRepo categoryRepo;

    @Mock
    private TagRepo tagRepo;

    @Mock
    private HttpSession session;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);


        ViewResolver viewResolver = (viewName, locale) -> new InternalResourceView("/WEB-INF/views/" + viewName + ".jsp");

        mockMvc = MockMvcBuilders
                .standaloneSetup(baseController)
                .setViewResolvers(viewResolver)
                .build();
    }


    @Test
    void testErrorPage() throws Exception {
        mockMvc.perform(get("/error"))
                .andExpect(status().isOk())
                .andExpect(view().name("error"));
    }
}
