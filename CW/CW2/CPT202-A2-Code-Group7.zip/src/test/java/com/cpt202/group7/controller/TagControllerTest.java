package com.cpt202.group7.controller;

import com.cpt202.group7.model.MusicResource;
import com.cpt202.group7.model.Tag;
import com.cpt202.group7.model.User;
import com.cpt202.group7.repository.CategoryRepo;
import com.cpt202.group7.repository.MusicResourceRepo;
import com.cpt202.group7.repository.TagRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.ui.Model;
import org.springframework.mock.web.MockHttpSession;

import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.assertEquals; // 添加这个导入

public class TagControllerTest {

    @InjectMocks
    private TagController tagController;

    @Mock
    private TagRepo tagRepo;

    @Mock
    private MusicResourceRepo musicResourceRepo;

    @Mock
    private Model model;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAllTags() {

        User mockUser = new User();
        mockUser.setId(1);
        mockUser.setEmail("test@example.com");
        mockUser.setRole(1);
        mockUser.setStatus(0);
        MockHttpSession mockSession = new MockHttpSession();
        mockSession.setAttribute("loginUser", mockUser);
        String viewName = tagController.getAllTags(mockSession, model);

        List<Tag> tags = new ArrayList<>();

        when(tagRepo.findByUserAndStatus(mockUser, 0)).thenReturn(tags);

        verify(model).addAttribute("tags", Collections.emptyList());
        assertEquals("tag", viewName);
    }

    @Test
    public void testAddTag() {
        Tag tag = new Tag();
        tag.setName("New Tag");

        User mockUser = new User();
        mockUser.setId(1);
        mockUser.setEmail("test@example.com");
        mockUser.setRole(1);
        mockUser.setStatus(0);
        MockHttpSession mockSession = new MockHttpSession();
        mockSession.setAttribute("loginUser", mockUser);

        String viewName = tagController.addTag(tag, mockSession, model);

        verify(tagRepo).save(any(Tag.class));
        verify(model).addAttribute("message", "Add tag successfully.");
        assertEquals("redirect:/tag", viewName);
    }

    @Test
    public void testEditTag() {
        Tag existingTag = new Tag();
        existingTag.setId(1);
        existingTag.setName("Old Tag");

        Tag updatedTag = new Tag();
        updatedTag.setId(1);
        updatedTag.setName("Updated Tag");

        User user = new User();
        user.setId(1);
        MockHttpSession mockSession = new MockHttpSession();
        mockSession.setAttribute("loginUser", user);

        when(tagRepo.findByUserAndIdAndStatus(user, 1, 0)).thenReturn(existingTag);

        String viewName = tagController.editTag(updatedTag, mockSession, model);

        verify(tagRepo).save(existingTag);
        assertEquals("redirect:/tag", viewName);
        assertEquals("Updated Tag", existingTag.getName());
    }

    @Test
    public void testDeleteTag() {
        Tag tag = new Tag();
        tag.setId(1);
        tag.setStatus(0);

        List<Tag> tags = new ArrayList<>();
        tags.add(tag);

        MusicResource musicResource = new MusicResource();
        musicResource.setStatus(0);
        musicResource.setTags(tags);

        List<MusicResource> musicResources = new ArrayList<>();
        musicResources.add(musicResource);

        User user = new User();
        user.setId(1);
        MockHttpSession mockSession = new MockHttpSession();
        mockSession.setAttribute("loginUser", user);

        when(tagRepo.findByUserAndIdAndStatus(user,1, 0)).thenReturn(tag);
        when(musicResourceRepo.findByUserAndStatusAndTagsIn(user, 1, tags)).thenReturn(musicResources);

        String viewName = tagController.deleteTag(1, mockSession, model);

        verify(tagRepo).save(tag);
        assertEquals(3, tag.getStatus());
        assertEquals("redirect:/tag", viewName);
    }
}
