package com.cpt202.group7.controller;

import com.cpt202.group7.model.MusicResource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
public class MusicPlayControllerTest {

    @InjectMocks
    private MusicPlayController musicPlayController;

    private MockMvc mockMvc;

    @BeforeEach
    public void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(musicPlayController).build();
    }


    @Test
    public void testPlay_WithValidParameters() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/play")
                        .param("fileName", "song.mp3")
                        .param("title", "Summer Vibes")
                        .param("cover", "cover.jpg")
                        .param("artist", "The Artist"))
                .andExpect(status().isOk())
                .andExpect(view().name("musicPlay"))
                .andExpect(model().attribute("fileName", "song.mp3"))
                .andExpect(model().attribute("title", "Summer Vibes"))
                .andExpect(model().attribute("cover", "cover.jpg"))
                .andExpect(model().attribute("artist", "The Artist"));
    }


    @Test
    public void testPlay_WithMissingParameters() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/play"))
                .andExpect(status().isOk())
                .andExpect(model().attribute("fileName", is(nullValue())))
                .andExpect(model().attribute("title", is(nullValue())))
                .andExpect(model().attribute("cover", is(nullValue())))
                .andExpect(model().attribute("artist", is(nullValue())));
    }


    @Test
    public void testPlay_WithPartialParameters() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/play")
                        .param("fileName", "demo.mp3")
                        .param("artist", "Unknown Artist"))
                .andExpect(status().isOk())
                .andExpect(model().attribute("fileName", "demo.mp3"))
                .andExpect(model().attribute("artist", "Unknown Artist"))
                // 使用精确匹配器
                .andExpect(model().attribute("title", is(nullValue())))
                .andExpect(model().attribute("cover", is(nullValue())));
    }
}
