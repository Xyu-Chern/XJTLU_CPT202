package com.cpt202.group7.service.impl;

import com.cpt202.group7.util.AbstractEmailContext;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.util.ReflectionTestUtils;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.*;

class EmailServiceImplTest {

    @Mock
    private JavaMailSender emailSender;

    @Mock
    private SpringTemplateEngine templateEngine;

    @InjectMocks
    private EmailServiceImpl emailService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        // Set the emailUser field manually
        ReflectionTestUtils.setField(emailService, "emailUser", "noreply@example.com");
    }

    @Test
    void testSendMail() throws MessagingException {
        // Arrange
        MimeMessage mimeMessage = mock(MimeMessage.class);
        when(emailSender.createMimeMessage()).thenReturn(mimeMessage);

        AbstractEmailContext emailContext = mock(AbstractEmailContext.class);
        when(emailContext.getTo()).thenReturn("test@example.com");
        when(emailContext.getSubject()).thenReturn("Test Subject");
        when(emailContext.getTemplateLocation()).thenReturn("email-template");
        Map<String, Object> contextVariables = new HashMap<>();
        contextVariables.put("key", "value");
        when(emailContext.getContext()).thenReturn(contextVariables);

        Context thymeleafContext = new Context();
        thymeleafContext.setVariables(contextVariables);

        // Mock templateEngine to return valid email content
        when(templateEngine.process(eq("email-template"), any(Context.class))).thenReturn("Processed Email Content");

        // Act & Assert
        assertDoesNotThrow(() -> emailService.sendMail(emailContext));

        // Verify
        verify(emailSender, times(1)).createMimeMessage();
        verify(templateEngine, times(1)).process(eq("email-template"), any(Context.class));
        verify(emailSender, times(1)).send(mimeMessage);
    }
}