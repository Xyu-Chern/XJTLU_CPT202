package com.cpt202.group7.controller;

import com.cpt202.group7.model.Category;
import com.cpt202.group7.model.MusicResource;
import com.cpt202.group7.model.User;
import com.cpt202.group7.repository.CategoryRepo;
import com.cpt202.group7.repository.MusicResourceRepo;
import com.cpt202.group7.repository.UserRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
public class UploadControllerTest {

    @InjectMocks
    private UploadController uploadController;

    @Mock
    private MusicResourceRepo musicResourceRepo;

    @Mock
    private UserRepo userRepo;

    @Mock
    private CategoryRepo categoryRepo;

    private MockMvc mockMvc;

    @BeforeEach
    public void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(uploadController).build();
    }

    @Test
    void testUploadMusic(@TempDir Path tempDir) throws Exception {

        User mockUser = new User();
        mockUser.setId(1);
        mockUser.setEmail("test@example.com");
        mockUser.setAvatar("avatar.jpg");
        mockUser.setUploadCount(0);
        mockUser.setRole(1);
        mockUser.setStatus(0);
        // Mock session
        MockHttpSession mockSession = new MockHttpSession();
        mockSession.setAttribute("loginUser", mockUser);

        // redirect: user.dir to temp directory
        System.setProperty("user.dir", tempDir.toString());

        // simulate two file: music and cover
        String musicName = "song.mp3";
        byte[] musicContent = "audio-data".getBytes();
        MockMultipartFile musicFile = new MockMultipartFile(
                "file", musicName, "audio/mpeg", musicContent);

        String imgName = "cover.png";
        byte[] imgContent = "image-data".getBytes();
        MockMultipartFile coverFile = new MockMultipartFile(
                "coverImg", imgName, "image/png", imgContent);

        Category category = new Category();
        category.setId(1);
        category.setVolume(1);
        when(categoryRepo.findByUserAndIdAndStatus(mockUser, 1,0)).thenReturn(category);

        // execute multipart request
        mockMvc.perform(MockMvcRequestBuilders.multipart("/upload")
                        .file(musicFile)
                        .file(coverFile)
                        .param("categoryId", category.getId().toString())
                        .session(mockSession))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/"));

        // Verify: file is stored at temp dir.
/*        Path savedMusic = tempDir.resolve("music").resolve(musicFile.getOriginalFilename());
        Path savedImg = tempDir.resolve("img").resolve(coverFile.getOriginalFilename());
        assertTrue(Files.exists(savedMusic), "Music file saved");
        assertTrue(Files.exists(savedImg), "CoverImg saved");*/

        // Changed: searching for dynamic file name containing currentTime.
        File[] musicFiles = tempDir.resolve("music").toFile().listFiles((dir, name) -> name.endsWith(musicName));
        assertNotNull(musicFiles, "Directory does not exist.");
        assertTrue(musicFiles.length > 0, "Music file saved.");
        Path savedMusic = musicFiles[0].toPath();

        File[] imgFiles = tempDir.resolve("img").toFile().listFiles((dir, name) -> name.endsWith(imgName));
        assertNotNull(imgFiles, "CoverImg does not exist.");
        assertTrue(imgFiles.length > 0, "CoverImg is saved.");
        Path savedImg = imgFiles[0].toPath();

        // Verify: Save method is called, and the Autowired arguments are right
        verify(musicResourceRepo).save(org.mockito.ArgumentMatchers.argThat(resource ->
                resource.getFileName().endsWith(musicName) &&
                        resource.getCover().endsWith(imgName) &&
                        resource.getStatus() == 1
        ));
    }
}
