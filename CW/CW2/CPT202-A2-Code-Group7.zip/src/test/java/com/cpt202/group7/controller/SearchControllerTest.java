package com.cpt202.group7.controller;

import com.cpt202.group7.model.Category;
import com.cpt202.group7.model.MusicResource;
import com.cpt202.group7.model.Tag;
import com.cpt202.group7.model.User;
import com.cpt202.group7.repository.CategoryRepo;
import com.cpt202.group7.repository.MusicResourceRepo;
import com.cpt202.group7.repository.TagRepo;
import org.antlr.v4.runtime.misc.Array2DHashSet;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.InternalResourceView;

import java.util.*;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

class SearchControllerTest {

    private MockMvc mockMvc;

    @InjectMocks
    private SearchController searchController;

    @Mock
    private MusicResourceRepo musicResourceRepo;

    @Mock
    private CategoryRepo categoryRepo;

    @Mock
    private TagRepo tagRepo;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        ViewResolver viewResolver = (viewName, locale) -> new InternalResourceView("/WEB-INF/views/" + viewName + ".jsp");

        mockMvc = MockMvcBuilders
                .standaloneSetup(searchController)
                .setViewResolvers(viewResolver)
                .build();
    }

    @Test
    void testGetSearchResult() throws Exception {
        MockHttpSession mockSession = new MockHttpSession();
        User mockUser = new User();
        mockUser.setId(1);
        mockUser.setEmail("test@example.com");
        mockUser.setRole(1);
        mockUser.setStatus(0);
        mockSession.setAttribute("loginUser", mockUser);

        when(musicResourceRepo.findByUserAndTitleLikeAndStatus(mockUser, "%test%", 0)).thenReturn(Collections.emptyList());
        when(categoryRepo.findByUserAndStatus(mockUser, 0)).thenReturn(Collections.emptyList());
        when(tagRepo.findByUserAndStatus(mockUser, 0)).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/search").param("query", "test").session(mockSession))
                .andExpect(status().isOk())
                .andExpect(view().name("searchResult"));
    }

    @Test
    void testFilterCategories_AllNull() throws Exception {
        MockHttpSession mockSession = new MockHttpSession();
        User mockUser = new User();
        mockUser.setId(1);
        mockUser.setEmail("test@example.com");
        mockUser.setRole(1);
        mockUser.setStatus(0);
        mockSession.setAttribute("loginUser", mockUser);

        when(musicResourceRepo.findByUserAndStatus(mockUser, 0)).thenReturn(Collections.emptyList());
        when(categoryRepo.findByUserAndStatus(mockUser, 0)).thenReturn(Collections.emptyList());
        when(tagRepo.findByUserAndStatus(mockUser, 0)).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/search").session(mockSession))
                .andExpect(status().isOk())
                .andExpect(view().name("searchResult"));
    }

    @Test
    void testFilterCategories_CategoryOnly() throws Exception {
        MockHttpSession mockSession = new MockHttpSession();
        User mockUser = new User();
        mockUser.setId(1);
        mockUser.setEmail("test@example.com");
        mockUser.setRole(1);
        mockUser.setStatus(0);
        mockSession.setAttribute("loginUser", mockUser);

        Category mockCategory = new Category();
        when(categoryRepo.findByUserAndIdAndStatus(mockUser, 1, 0)).thenReturn(mockCategory);
        when(musicResourceRepo.findByUserAndStatusAndCategory(mockUser, 0, mockCategory)).thenReturn(Collections.emptyList());
        when(categoryRepo.findByUserAndStatus(mockUser, 0)).thenReturn(Collections.emptyList());
        when(tagRepo.findByUserAndStatus(mockUser, 0)).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/search").param("categoryId", "1").session(mockSession))
                .andExpect(status().isOk())
                .andExpect(view().name("searchResult"));
    }

    @Test
    void testFilterCategories_TagOnly() throws Exception {
        MockHttpSession mockSession = new MockHttpSession();
        User mockUser = new User();
        mockUser.setId(1);
        mockUser.setEmail("test@example.com");
        mockUser.setRole(1);
        mockUser.setStatus(0);
        mockSession.setAttribute("loginUser", mockUser);

        Tag tag = new Tag();
        List<Tag> tags = new ArrayList<>();
        List<Integer> tagIds = new ArrayList<>();
        tags.add(tag);
        tagIds.add(2);

        when(tagRepo.findByUserAndStatusAndIdIn(mockUser, 0, tagIds)).thenReturn(tags);
        when(musicResourceRepo.findByUserAndStatusAndTagsIn(mockUser, 0, tags)).thenReturn(Collections.emptyList());
        when(categoryRepo.findByUserAndStatus(mockUser, 0)).thenReturn(Collections.emptyList());
        when(tagRepo.findByUserAndStatus(mockUser, 0)).thenReturn(tags);

        mockMvc.perform(get("/search").param("tagIds", "2").session(mockSession))
                .andExpect(status().isOk())
                .andExpect(view().name("searchResult"));
    }

    @Test
    void testFilterCategories_CategoryAndTags() throws Exception {
        MockHttpSession mockSession = new MockHttpSession();
        User mockUser = new User();
        mockUser.setId(1);
        mockUser.setEmail("test@example.com");
        mockUser.setRole(1);
        mockUser.setStatus(0);
        mockSession.setAttribute("loginUser", mockUser);

        Category mockCategory = new Category();
        Tag tag = new Tag();
        List<Tag> tags = new ArrayList<>();
        List<Integer> tagIds = new ArrayList<>();
        tags.add(tag);
        tagIds.add(2);

        when(categoryRepo.findByUserAndIdAndStatus(mockUser, 1, 0)).thenReturn(mockCategory);
        when(tagRepo.findByUserAndStatusAndIdIn(mockUser, 0, tagIds)).thenReturn(tags);
        when(musicResourceRepo.findByUserAndStatusAndCategoryAndTagsIn(mockUser, 0, mockCategory, tags)).thenReturn(Collections.emptyList());
        when(categoryRepo.findByUserAndStatus(mockUser, 0)).thenReturn(Collections.emptyList());
        when(tagRepo.findByUserAndStatus(mockUser, 0)).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/search")
                        .param("categoryId", "1")
                        .param("tagIds", "2")
                        .session(mockSession))
                .andExpect(status().isOk())
                .andExpect(view().name("searchResult"));
    }
}
