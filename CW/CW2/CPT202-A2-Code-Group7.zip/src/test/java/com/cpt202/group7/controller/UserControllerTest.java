package com.cpt202.group7.controller;

import com.cpt202.group7.exception.InvalidTokenException;
import com.cpt202.group7.model.User;
import com.cpt202.group7.repository.UserRepo;
import com.cpt202.group7.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.multipart.MultipartFile;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)  // Enable Mockito support in JUnit 5
public class UserControllerTest {

    @InjectMocks
    private UserController userController;  // Inject the mocked dependencies into the controller

    @Mock
    private UserRepo userRepo;  // Mock UserRepo

    @Mock
    private UserService userService;  // Mock UserService

    private MockMvc mockMvc;  // MockMvc for simulating requests

    private BCryptPasswordEncoder encoder;

    @BeforeEach
    public void setUp() {
        encoder = new BCryptPasswordEncoder();
        mockMvc = MockMvcBuilders.standaloneSetup(userController).build(); // Initialize MockMvc for testing only this controller
    }

    @Test
    public void testGetRegisterPage() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/register"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("registerPage")); // Updated view name
    }

    @Test
    public void testPostRegisterPage_Success() throws Exception {
        User user = new User();
        user.setEmail("test@example.com");
        user.setPassword("Password123!");

        // Simulate unverified email
        when(userRepo.findByEmail(user.getEmail())).thenReturn(null);

        // Simulate Success registration
        doNothing().when(userService).register(any(User.class), any(MultipartFile.class));

        //  Create MockMultipartFile
        MockMultipartFile mockFile = new MockMultipartFile(
                "avatarFile",
                "test-avatar.jpg",
                "image/jpeg",
                "test-avatar-content".getBytes()
        );

        mockMvc.perform(MockMvcRequestBuilders.multipart("/register")
                        .file(mockFile)
                        .param("email", user.getEmail())
                        .param("password", user.getPassword())
                        .param("confirmPassword", user.getPassword()))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("registerPage"));
//                .andExpect(MockMvcResultMatchers.model().attribute("message", "Registration successful. Please check your email for the activation link."));

        verify(userService, times(1)).register(any(User.class), any(MultipartFile.class));
    }

    @Test
    public void testPostRegisterPage_EmailAlreadyRegistered() throws Exception {
        User user = new User();
        user.setEmail("test@example.com");
        user.setPassword("Password123!");
        user.setStatus(0);

        // Simulate that the email is already registered
        when(userRepo.findByEmail(user.getEmail())).thenReturn(new User());

        mockMvc.perform(MockMvcRequestBuilders.post("/register")
                        .param("email", user.getEmail())
                        .param("password", user.getPassword())
                        .param("confirmPassword", user.getPassword()))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("registerPage"))
                .andExpect(MockMvcResultMatchers.model().attribute("error", "Email already registered"));
    }

    @Test
    public void testPostLoginPage_Success() throws Exception {
        User user = new User();
        user.setEmail("test@example.com");
        user.setPassword("Password123!");
        user.setRole(1);  // Admin role
        user.setStatus(0);  // Active status

        // BCrypt encode password
        String encodedPassword = encoder.encode(user.getPassword());
        user.setPassword(encodedPassword);

        // Simulate finding the user in the repository
        when(userRepo.findByEmail(user.getEmail())).thenReturn(user);

        mockMvc.perform(MockMvcRequestBuilders.post("/login")
                        .param("email", user.getEmail())
                        .param("password", "Password123!"))
                .andExpect(MockMvcResultMatchers.status().isFound())  // Expect a redirect
                .andExpect(MockMvcResultMatchers.redirectedUrl("/"));  // Redirect to homepage
    }

    @Test
    public void testGetAvatar() throws Exception {
        User user = new User();
        user.setEmail("test@example.com");
        user.setAvatar("avatar.jpg");

        // Simulate finding a user with an avatar
        when(userRepo.findByEmail("test@example.com")).thenReturn(user);

        mockMvc.perform(MockMvcRequestBuilders.get("/getAvatar")
                        .param("email", "test@example.com"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().string("/img/avatar.jpg"));  // Expect avatar path
    }

    @Test
    public void testVerifyUser_Success() throws Exception {
        String token = "validToken";

        // Simulate a successful token verification
        when(userService.verifyUser(token)).thenReturn(true);

        mockMvc.perform(MockMvcRequestBuilders.get("/register/verify")
                        .param("token", token))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("verificationResult"))
                .andExpect(MockMvcResultMatchers.model().attribute("message", "Account verified successfully"));
    }

    @Test
    public void testVerifyUser_Failure() throws Exception {
        String token = "invalidToken";

        // Simulate a failure in token verification
        when(userService.verifyUser(token)).thenThrow(new InvalidTokenException("Invalid token"));

        mockMvc.perform(MockMvcRequestBuilders.get("/register/verify")
                        .param("token", token))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("verificationResult"))
                .andExpect(MockMvcResultMatchers.model().attribute("error", "Invalid verification token"));
    }
}
