package com.cpt202.group7.service;

import com.cpt202.group7.model.MusicResource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface MusicResourceService {
    MusicResource addMusicResource(MusicResource musicResource);
    List<MusicResource> getAllMusicResources();
    // Other music resource-related methods
}
