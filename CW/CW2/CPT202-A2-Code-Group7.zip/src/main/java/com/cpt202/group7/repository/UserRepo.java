package com.cpt202.group7.repository;

import com.cpt202.group7.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepo extends JpaRepository<User, Integer> {
    User findByEmail(String email);
    User findFirstById(Integer id);
    List<User> findByRole(Integer role);
    List<User> findByRoleAndStatus(Integer role, Integer status);
    // Remove custom findById and use the one from JpaRepository
    void deleteById(Integer id);
}
