package com.cpt202.group7.controller;

import com.cpt202.group7.model.User;
import com.cpt202.group7.repository.UserRepo;
import com.cpt202.group7.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.apache.kafka.common.protocol.types.Field;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

@Controller
public class UserProfileController {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private UserService userService;

    @RequestMapping(value="/view/uploads/**",method= {RequestMethod.GET})//  a/b/c.gif
    public void view(HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException {
        String fileName = request.getRequestURI();
        fileName = fileName.substring(fileName.indexOf("uploads")+8);

        String uploadDir = System.getProperty("user.dir") + "/src/main/resources/static/img";

        String ffname = new String(fileName.getBytes("GB2312"), "ISO-8859-1");

        response.setContentType("application/force-download");
        response.addHeader("Content-Disposition", "attachment;fileName=" + ffname);

        File file = new File(uploadDir+File.separator+fileName);
        try {
            FileCopyUtils.copy(new FileInputStream(file), response.getOutputStream());
        } catch (IOException e) {
            return ;
        }
    }

    // View user profile by ID
    @GetMapping("/profile")
    public String viewProfile(Model model, HttpSession session) {
        User user = (User) session.getAttribute("loginUser");
        model.addAttribute("user", user);  // Add user information to the model
        model.addAttribute("avatar", user.getAvatar());
        return "profilePage";  // Return the view name
    }

    // Update user profile information
    @PostMapping("/profile/update")
    public String updateProfile(Integer id,
                                String name,
                                String email,
                                String avatar,
                                @RequestParam(required = false) String currentPassword,
                                @RequestParam(required = false) String newPassword,
                                @RequestParam(required = false) String confirmPassword,
                                HttpSession session,
                                Model m) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(12);
        String passwordPattern = "^(?=.*[0-9])(?=.*[!@#$%^&*])[A-Za-z0-9!@#$%^&*]{8,}$";
        String emailPattern = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";

        User loginUser = (User) session.getAttribute("loginUser");
        m.addAttribute("user", loginUser);
        m.addAttribute("avatar", loginUser.getAvatar());

        // Fetch the user from the database
        User user = userRepo.findFirstById(id);

        if (name != null) {
            user.setName(name);
        }

        if (avatar != null) {
            user.setAvatar(avatar);
        }

        if (loginUser.getRole() == 0) {

            if (email != null && email.matches(emailPattern)) {
                user.setEmail(email);
            } else if (email != null && !email.matches(emailPattern)) {
                m.addAttribute("updateError", "Invalid email format");
                return "profileAdminPage";
            }

            if (newPassword != null && !encoder.matches(currentPassword, user.getPassword())) {
                m.addAttribute("updateError", "Current Password Incorrect");
                return "profileAdminPage";
            } else if (newPassword != null && !newPassword.equals(confirmPassword)) {
                m.addAttribute("updateError", "Confirm Password Incorrect");
                return "profileAdminPage";
            } else if (newPassword != null && newPassword.equals(confirmPassword) && newPassword.matches(passwordPattern)) {
                m.addAttribute("updateMesssage", "Update Password And Profile Successfully");
                user.setPassword(encoder.encode(newPassword));
                userRepo.save(user);
                return "redirect:/login";
            } else if (newPassword != null && !newPassword.matches(passwordPattern)) {
                m.addAttribute("updateError", "Password must be at least 8 characters long, contain at least one number, and one special character");
                return "profileAdminPage";
            }

            userRepo.save(user);
            if (!m.containsAttribute("updateError")) {
                m.addAttribute("updateMessage", "Update Profile Successfully");
            }
            return "profileAdminPage";
        }

        if (email != null && email.matches(emailPattern)) {
            user.setEmail(email);
        } else if (email != null && !email.matches(emailPattern)) {
            m.addAttribute("updateError", "Invalid email format");
            return "profilePage";
        }

        if (newPassword != null && !encoder.matches(currentPassword, user.getPassword())) {
            m.addAttribute("updateError", "Current Password Incorrect");
            return "profilePage";
        } else if (newPassword != null && newPassword.equals(confirmPassword) && newPassword.matches(passwordPattern)) {
            m.addAttribute("updateMesssage", "Update Password And Profile Successfully");
            user.setPassword(encoder.encode(newPassword));
            userRepo.save(user);
            return "redirect:/login";
        } else if (newPassword != null && !newPassword.matches(passwordPattern)) {
            m.addAttribute("updateError", "Password must be at least 8 characters long, contain at least one number, and one special character");
            return "profilePage";
        }

        userRepo.save(user);
        if (!m.containsAttribute("updateError")) {
            m.addAttribute("updateMessage", "Update Profile Successfully");
        }

        return "profilePage";
    }

    // Display the success page after updating the profile
    @GetMapping("/updateProfileSuccess")
    public String showUpdateProfileSuccessPage() {
        return "updateProfileSuccess";  // Return the success page view
    }
}
