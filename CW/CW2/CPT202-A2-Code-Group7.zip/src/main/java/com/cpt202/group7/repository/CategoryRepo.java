package com.cpt202.group7.repository;

import com.cpt202.group7.model.Category;
import com.cpt202.group7.model.Tag;
import com.cpt202.group7.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CategoryRepo extends JpaRepository<Category, Integer> {
    List<Category> findByUserAndStatus(User user, Integer status);
    Category findByUserAndIdAndStatus(User user, Integer id, Integer status);
}
