package com.cpt202.group7.service.impl;

import com.cpt202.group7.model.MusicResource;
import com.cpt202.group7.service.MusicResourceService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class MusicResourceServiceImpl implements MusicResourceService {

    private List<MusicResource> musicResources = new ArrayList<>();

    @Override
    public MusicResource addMusicResource(MusicResource musicResource) {
        musicResources.add(musicResource);
        return musicResource;
    }

    @Override
    public List<MusicResource> getAllMusicResources() {
        return musicResources;
    }
}
