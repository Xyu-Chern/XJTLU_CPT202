package com.cpt202.group7.controller;

import com.cpt202.group7.model.Category;
import com.cpt202.group7.model.MusicResource;
import com.cpt202.group7.model.Tag;
import com.cpt202.group7.model.User;
import com.cpt202.group7.repository.MusicResourceRepo;
import com.cpt202.group7.repository.UserRepo;
import com.cpt202.group7.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Set;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private MusicResourceRepo musicResourceRepo;

    @Autowired
    private UserService userService;

    @GetMapping("")
    public String getAdminPage(HttpSession session, Model m) {
        User loginUser = (User) session.getAttribute("loginUser");
        if (loginUser.getRole() == 0) {
            return "redirect:/admin/audit";
        }
        return "redirect:/login";
    }

    @GetMapping("/users")
    public String users(HttpSession session, @RequestParam(value = "status", required = false) Integer status, Model m) {
        User loginUser = (User) session.getAttribute("loginUser");
        if (loginUser.getRole() == 0) {
            m.addAttribute("avatar",loginUser.getAvatar());
            if (status != null) {
                m.addAttribute("selected", status);
                m.addAttribute("users", userRepo.findByRoleAndStatus(1, status));
            }
            else {
                m.addAttribute("selected", null);
                m.addAttribute("users", userRepo.findByRole(1));
            }
            return "users";
        }
        return "redirect:/login";
    }

    // audit main page (with session verification)
    @GetMapping("/audit")
    public String getAuditPage(HttpSession session, @RequestParam(value = "status", required = false) Integer status, Model m) {
        User loginUser = (User) session.getAttribute("loginUser");
        if (loginUser.getRole() == 0) {
            m.addAttribute("avatar", loginUser.getAvatar());
            if (status != null) {
                m.addAttribute("selected", status);
                m.addAttribute("result", musicResourceRepo.findByStatus(status));
            }
            else {
                m.addAttribute("selected", status);
                m.addAttribute("result", musicResourceRepo.findAll());
            }
            return "audit";
        }
        return "redirect:/login";
    }

    // handle lock user operations
    @PostMapping("/audit")
    public String postAuditPage(
            Integer id,
            Integer status,
            HttpSession session,
            Model m) {

        // check if is admin login
        User adminUser = (User) session.getAttribute("loginUser");
        if (adminUser == null || adminUser.getRole() != 0) {
            return "redirect:/login";
        }

        MusicResource musicResource = musicResourceRepo.findFirstById(id);
        if (musicResource == null) {
            m.addAttribute("error", "Music Resource Not Found");
            return "redirect:/admin/audit";
        }

        if ((status == 0 || status == 1) && musicResource.getStatus() == 2) {
            User uploadUser = musicResource.getUser();
            uploadUser.setBanCount(uploadUser.getBanCount() - 1);
        }

        if (status == 2 && musicResource.getStatus() != 2) {
            User uploadUser = musicResource.getUser();
            uploadUser.setBanCount(uploadUser.getBanCount() + 1);
            Category category = musicResource.getCategory();
            if (category != null) {
                category.setVolume(category.getVolume() - 1);
            }
            List<Tag> tags = musicResource.getTags();
            if (!CollectionUtils.isEmpty(tags)) {
                for (Tag tag : tags) {
                    tag.setVolume(tag.getVolume() - 1);
                }
            }
            musicResource.setCategory(null);
            musicResource.setTags(null);
        }

        musicResource.setStatus(status);
        musicResourceRepo.save(musicResource);
        return "redirect:/admin/audit";

    }

    // handle lock user operations
    @PostMapping("/users/lock")
    public String lockUser(
            Integer userId,
            Model m,
            HttpSession session) {

        // check if is admin login
        User adminUser = (User) session.getAttribute("loginUser");
        if (adminUser == null || adminUser.getRole() != 0) {
            return "redirect:/login";
        }

        // handle user status changes
        User existingUser = userRepo.findFirstById(userId);
        if (existingUser != null) {
            // if is admin, cannot modify other admins
            if (existingUser.getRole() == 0) {
                m.addAttribute("error", "Cannot modify admins");
                return "redirect:/admin/users";
            }
            existingUser.setStatus(2);
            userRepo.save(existingUser);
            return "redirect:/admin/users";
        } else {
            m.addAttribute("error", "User not found");
            return "redirect:/admin/users";
        }

    }

    @PostMapping("/users/unlock")
    public String unlockUser(
            Integer userId,
            Model m,
            HttpSession session) {

        // check if is admin login
        User adminUser = (User) session.getAttribute("loginUser");
        if (adminUser == null || adminUser.getRole() != 0) {
            return "redirect:/login";
        }

        // handle user status changes
        User existingUser = userRepo.findFirstById(userId);
        if (existingUser != null) {
            // if is admin, cannot modify other admins
            if (existingUser.getRole() == 0) {
                m.addAttribute("error", "Cannot modify admins");
                return "redirect:/admin/users";
            }
            existingUser.setStatus(0);
            userRepo.save(existingUser);
            return "redirect:/admin/users";
        } else {
            m.addAttribute("error", "User not found");
            return "redirect:/admin/users";
        }

    }

    @GetMapping("/profile")
    public String viewProfile(Model model, HttpSession session) {
        User user = (User) session.getAttribute("loginUser");
        if (user.getRole() == 0) {
            model.addAttribute("user", user);  // Add user information to the model
            model.addAttribute("avatar", user.getAvatar());
            return "profileAdminPage";  // Return the view name
        }
        return "redirect:/login";
    }

    @RequestMapping(value="/view/uploads/**",method= {RequestMethod.GET})//  a/b/c.gif
    public void view(HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException {
        String fileName = request.getRequestURI();
        fileName = fileName.substring(fileName.indexOf("uploads")+8);

        String uploadDir = System.getProperty("user.dir") + "/src/main/resources/static/img";

        String ffname = new String(fileName.getBytes("GB2312"), "ISO-8859-1");

        response.setContentType("application/force-download");
        response.addHeader("Content-Disposition", "attachment;fileName=" + ffname);

        File file = new File(uploadDir+File.separator+fileName);
        try {
            FileCopyUtils.copy(new FileInputStream(file), response.getOutputStream());
        } catch (IOException e) {
            return ;
        }
    }

    // Update user profile information
    @PostMapping("/profile/update")
    public String updateProfile(@RequestBody User form, HttpSession session) {
        User adminUser = (User) session.getAttribute("loginUser");
        if (adminUser == null || adminUser.getRole() == 0) {
            User user = userService.getUserById(form.getId());

            // Update user profile information
            user.setEmail(form.getEmail());
            user.setAvatar(form.getAvatar());

            // Save updated user information
            userService.updateUserInfo(form.getId(), user);

            // Redirect to the success page after profile update
            return "redirect:/admin/profile";
        }
        return "redirect:/login";
    }

}
