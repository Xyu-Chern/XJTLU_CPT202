package com.cpt202.group7.model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;
import java.util.Set;

@Data
@Entity
public class MusicResource {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String fileName;
    private String title;
    private String artist;
    private String cover;
    private String album;
    @ManyToOne
    @JoinColumn(name = "category_id")
    private Category category;
    @ManyToOne
    private User user;
    @ManyToMany
    private List<Tag> tags;
    private Integer status; // 0通过审核 1正在审核 2封禁中 3已删除
}
