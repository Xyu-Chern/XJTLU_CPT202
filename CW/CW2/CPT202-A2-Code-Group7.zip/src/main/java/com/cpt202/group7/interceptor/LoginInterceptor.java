package com.cpt202.group7.interceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class LoginInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 获取当前请求的URI
        String requestURI = request.getRequestURI();

        // 不需要拦截的资源和路径
        if (requestURI.contains("/static/") ||
                requestURI.contains("/login") ||
                requestURI.contains("/register") ||
                requestURI.contains("/error") ||
                requestURI.contains("/register/verify")) {
            return true;
        }

        // 检查用户是否已登录
        HttpSession session = request.getSession();
        Object user = session.getAttribute("loginUser");

        // 如果用户已登录，允许访问
        if (user != null) {
            return true;
        }

        // 未登录则重定向到登录页面
        response.sendRedirect("/login");
        return false;
    }
}
