package com.cpt202.group7.controller;

import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.cpt202.group7.interceptor.LoginInterceptor;
import com.cpt202.group7.model.Category;
import com.cpt202.group7.model.MusicResource;
import com.cpt202.group7.model.Tag;
import com.cpt202.group7.model.User;
import com.cpt202.group7.repository.CategoryRepo;
import com.cpt202.group7.repository.MusicResourceRepo;
import com.cpt202.group7.repository.TagRepo;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@Controller
public class SearchController {
    @Autowired
    private MusicResourceRepo musicResourceRepo;

    @Autowired
    private CategoryRepo categoryRepo;

    @Autowired
    private TagRepo tagRepo;

    @GetMapping("/search")
    public String searchAndFilter(@RequestParam(required = false) String query,
                                   @RequestParam(required = false) Integer categoryId,
                                   @RequestParam(required = false) List<Integer> tagIds,
                                   HttpSession session,
                                   Model m) {
        User loginUser = (User) session.getAttribute("loginUser");
        Category category = categoryRepo.findByUserAndIdAndStatus(loginUser, categoryId, 0);
        List<Tag> tags = tagRepo.findByUserAndStatusAndIdIn(loginUser, 0, tagIds);
        User user = (User) session.getAttribute("loginUser");
        List<MusicResource> musicResources;
        if (query == null) {
            if (categoryId == null || CollectionUtils.isEmpty(tagIds)) {
                if (categoryId == null && CollectionUtils.isEmpty(tagIds)) {
                    m.addAttribute("selectedCategory", null);
                    m.addAttribute("selectedTags", null);
                    musicResources = musicResourceRepo.findByUserAndStatus(loginUser, 0);
                }
                else if (CollectionUtils.isEmpty(tagIds)) {
                    m.addAttribute("selectedCategory", categoryId);
                    m.addAttribute("selectedTags", null);
                    musicResources = musicResourceRepo.findByUserAndStatusAndCategory(loginUser, 0, category);
                }
                else {
                    Iterator<Integer> iterator = tagIds.iterator();
                    m.addAttribute("selectedCategory", null);
                    m.addAttribute("selectedTags", iterator.next());
                    musicResources = musicResourceRepo.findByUserAndStatusAndTagsIn(loginUser, 0, tags);
                }
            }
            else {
                Iterator<Integer> iterator = tagIds.iterator();
                m.addAttribute("selectedCategory", categoryId);
                m.addAttribute("selectedTags", iterator.next());
                musicResources = musicResourceRepo.findByUserAndStatusAndCategoryAndTagsIn(loginUser, 0, category, tags);
            }
        }
        else {
            if (categoryId == null || CollectionUtils.isEmpty(tagIds)) {
                if (categoryId == null && CollectionUtils.isEmpty(tagIds)) {
                    m.addAttribute("query", query);
                    m.addAttribute("selectedCategory", null);
                    m.addAttribute("selectedTags", null);
                    musicResources = musicResourceRepo.findByUserAndTitleLikeAndStatus(loginUser, '%'+query+'%', 0);
                }
                else if (CollectionUtils.isEmpty(tagIds)) {
                    m.addAttribute("query", query);
                    m.addAttribute("selectedCategory", categoryId);
                    m.addAttribute("selectedTags", null);
                    musicResources = musicResourceRepo.findByUserAndTitleLikeAndStatusAndCategory(loginUser, '%'+query+'%', 0, category);
                }
                else {
                    Iterator<Integer> iterator = tagIds.iterator();
                    m.addAttribute("query", query);
                    m.addAttribute("selectedCategory", null);
                    m.addAttribute("selectedTags", iterator.next());
                    musicResources = musicResourceRepo.findByUserAndTitleLikeAndStatusAndTagsIn(loginUser, '%'+query+'%', 0, tags);
                }
            }
            else {
                Iterator<Integer> iterator = tagIds.iterator();
                m.addAttribute("query", query);
                m.addAttribute("selectedCategory", categoryId);
                m.addAttribute("selectedTags", iterator.next());
                musicResources = musicResourceRepo.findByUserAndTitleLikeAndStatusAndCategoryAndTagsIn(loginUser, '%'+query+'%', 0, category, tags);
            }
        }

        m.addAttribute("avatar", user.getAvatar());
        m.addAttribute("result", musicResources);
        m.addAttribute("count", musicResources.size());
        m.addAttribute("categories", categoryRepo.findByUserAndStatus(loginUser, 0));
        m.addAttribute("tags", tagRepo.findByUserAndStatus(loginUser, 0));
        return "searchResult";
    }



}
