package com.cpt202.group7.repository;

import com.cpt202.group7.model.Category;
import com.cpt202.group7.model.MusicResource;
import com.cpt202.group7.model.Tag;
import jakarta.persistence.criteria.CriteriaBuilder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cpt202.group7.model.User;

import java.util.Collection;
import java.util.List;
import java.util.Set;

@Repository
public interface MusicResourceRepo extends JpaRepository<MusicResource, Integer> {
    List<MusicResource> findByUserAndTitleLikeAndStatus(User user, String query, Integer status);
    List<MusicResource> findByUserAndTitleLikeAndStatusAndCategoryAndTagsIn(User user, String query, Integer status, Category category, List<Tag> tags);
    List<MusicResource> findByUserAndTitleLikeAndStatusAndCategory(User user, String query, Integer status, Category category);
    List<MusicResource> findByUserAndTitleLikeAndStatusAndTagsIn(User user, String query, Integer status, List<Tag> tags);
    List<MusicResource> findByUserAndStatus(User user, Integer status);
    List<MusicResource> findByUserAndStatusAndCategoryAndTagsIn(User user, Integer status, Category category, List<Tag> tags);
    List<MusicResource> findByUserAndStatusAndCategory(User user, Integer status, Category category);
    List<MusicResource> findByUserAndStatusAndTagsIn(User user, Integer status, List<Tag> tags);
    List<MusicResource> findByStatus(Integer status);
    MusicResource findFirstById(Integer id);
    MusicResource findByUserAndIdAndStatus(User user, Integer id, int status);
}
