package com.cpt202.group7.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Data
@Entity
public class Tag {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String name;
    private Integer status; // 0通过审核 1正在审核 2封禁中 3已删除
    private Integer volume;
    @ManyToOne
    private User user;
}
