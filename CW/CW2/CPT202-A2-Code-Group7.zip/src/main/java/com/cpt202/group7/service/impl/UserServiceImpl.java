package com.cpt202.group7.service.impl;

import com.cpt202.group7.exception.InvalidTokenException;
import com.cpt202.group7.exception.UserAlreadyActivatedException;
import com.cpt202.group7.service.EmailService;
import com.cpt202.group7.service.SecureTokenService;
import com.cpt202.group7.service.UserService;
import com.cpt202.group7.util.AccountVerificationEmailContext;
import com.cpt202.group7.model.SecureToken;
import com.cpt202.group7.model.User;
import com.cpt202.group7.repository.UserRepo;
import jakarta.mail.MessagingException;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.Objects;

@Service
public class UserServiceImpl implements UserService {

    @Value("${site.base.url.http}")
    private String baseUrl;

    private final UserRepo userRepo;
    private final SecureTokenService secureTokenService;
    private final EmailService emailService;
    private BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(12);
    @Autowired
    public UserServiceImpl(UserRepo userRepo, SecureTokenService secureTokenService, EmailService emailService) {
        this.userRepo = userRepo;
        this.secureTokenService = secureTokenService;
        this.emailService = emailService;
    }

    @Override
    public void register(User user, MultipartFile avatarFile) {
        // Validate the user fields
        user.setPassword(encoder.encode(user.getPassword()));
        user.setEmail(user.getEmail());
        user.setRole(1);  // Default role as user
        user.setStatus(1);  // Set the user status to inactive initially
        user.setName(user.getName());
        user.setUploadCount(0);
        user.setBanCount(0);
        userRepo.save(user); // Save user

        // Handle avatar file if provided
        if (avatarFile != null && !avatarFile.isEmpty()) {
            uploadAvatarFile(user, avatarFile);  // Upload avatar if the file is provided
        } else {
            user.setAvatar("default-avatar.jpg");  // Default avatar if no file provided
        }

        userRepo.save(user);  // Save user with avatar
        sendRegistrationConfirmationEmail(user);  // Send confirmation email
    }

    // Handle avatar file upload separately
    public void uploadAvatarFile(User user, MultipartFile avatarFile) {
        String uploadDir = System.getProperty("user.dir") + "/img";
        File directory = new File(uploadDir);

        // Ensure the directory exists
        if (!directory.exists()) {
            if (!directory.mkdirs()) {
                throw new RuntimeException("Failed to create directory: " + uploadDir);
            }
        }

        String timestamp = String.valueOf(System.currentTimeMillis());
        String originalFileName = avatarFile.getOriginalFilename();
        String fileExtension = originalFileName.substring(originalFileName.lastIndexOf("."));
        String fileName = "avatar_" + user.getId() + "_" + timestamp + fileExtension;
        File destinationFile = new File(directory, fileName);

        try {
            avatarFile.transferTo(destinationFile);
            user.setAvatar(fileName);  // Set the avatar filename
        } catch (IOException e) {
            throw new RuntimeException("Failed to save avatar file", e);
        }
    }

    @Override
    public void sendRegistrationConfirmationEmail(User user) {
        SecureToken secureToken = secureTokenService.createToken();
        secureToken.setUser(user);
        secureTokenService.saveSecureToken(secureToken);

        // Create email context and initialize
        AccountVerificationEmailContext context = new AccountVerificationEmailContext();
        context.init(user);  // Initialize email context
        context.setToken(secureToken.getToken());  // Set the token
        context.buildVerificationUrl(baseUrl, secureToken.getToken());  // Set verification URL

        try {
            emailService.sendMail(context);  // Send the email
        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean verifyUser(String token) throws InvalidTokenException, UserAlreadyActivatedException {
        SecureToken secureToken = secureTokenService.findByToken(token);
        User user = userRepo.findById(secureToken.getUser().getId()).orElse(null);

        if (Objects.isNull(user)) {
            return false;  // Return false if the user is not found
        }

        if (user.getStatus() == 0) {  // If user is already activated
            throw new UserAlreadyActivatedException("User has already been activated");
        }

        if (secureToken.isExpired()) {
            throw new InvalidTokenException("Token is invalid or expired");
        }

        if (secureToken.isUsed()) {
            throw new InvalidTokenException("Token has already been used");
        }

        // Activate the user
        user.setStatus(0);  // Mark the user as activated
        userRepo.save(user);  // Save user with updated status

        // Mark token as used
        secureToken.setUsed(true);
        secureTokenService.saveSecureToken(secureToken);  // Save token

        return true;
    }

    @Override
    public void updateUserInfo(Integer userId, User updatedUser) {
        User existingUser = userRepo.findById(userId).orElse(null);
        if (existingUser != null) {
            // Update user's email and avatar
            existingUser.setEmail(updatedUser.getEmail());
            existingUser.setAvatar(updatedUser.getAvatar());
            userRepo.save(existingUser);  // Save updated user information
        }
    }

    @Override
    public User getUserById(Integer userId) {
        return userRepo.findById(userId).orElse(null);  // Fetch user by ID
    }

    @Override
    @Transactional
    public void updatePwd(User user, String code) {
        SecureToken token = secureTokenService.findByTokenAndUserId(user.getId(), code);
        if (token == null) {
            throw new RuntimeException("Verification code expired");
        }

        User u = this.getUserById(user.getId());
        u.setPassword(user.getPassword());
        userRepo.save(u);  // Save updated password

        token.setUsed(true);  // Mark token as used
        secureTokenService.saveSecureToken(token);  // Save token
    }

    // Send verification email for code
    @Override
    public void sendCodeConfirmationEmail(User user) {
        SecureToken secureToken = secureTokenService.createToken();
        secureToken.setToken(RandomStringUtils.randomNumeric(4));
        secureToken.setUser(user);
        secureTokenService.saveSecureToken(secureToken);

        // 创建邮件上下文并初始化
        AccountVerificationEmailContext context = new AccountVerificationEmailContext();
        context.init(user);  // 初始化邮件上下文
        context.setTemplateLocation("pwdVerification");
        context.setSubject("Verification Code");
        context.setToken(secureToken.getToken());  // 设置 token
//        context.buildVerificationUrl(baseUrl, secureToken.getToken());  // 设置验证 URL
        context.put("code",secureToken.getToken());
        try {
            emailService.sendMail(context);  // 发送邮件
        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }
    }
}
