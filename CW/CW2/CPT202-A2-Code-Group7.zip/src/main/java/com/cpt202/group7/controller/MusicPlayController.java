package com.cpt202.group7.controller;

import com.cpt202.group7.model.MusicResource;
import com.cpt202.group7.repository.MusicResourceRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.ui.Model;

@Controller
public class MusicPlayController {

    @GetMapping("/play")
    public String playController(Model m, MusicResource mr) {
        m.addAttribute("fileName", mr.getFileName());
        m.addAttribute("title", mr.getTitle());
        m.addAttribute("cover", mr.getCover());
        m.addAttribute("artist", mr.getArtist());
        return "musicPlay";
    }
}
