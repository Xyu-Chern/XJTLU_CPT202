package com.cpt202.group7.service;

import com.cpt202.group7.util.AbstractEmailContext;  // Use the correct import based on your project structure
import jakarta.mail.MessagingException;

public interface EmailService {
    void sendMail(final AbstractEmailContext email) throws MessagingException;
}
