package com.cpt202.group7.controller;

import org.springframework.ui.Model;
import com.cpt202.group7.model.User;
import com.cpt202.group7.repository.UserRepo;
import com.cpt202.group7.service.UserService;
import com.cpt202.group7.service.EmailService;
import com.cpt202.group7.util.AccountVerificationEmailContext;
import jakarta.mail.MessagingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.HashMap;
import java.util.Map;

@Controller
public class UserUpdateProfileController {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private UserService userService;

    @Autowired
    private EmailService emailService;

    @GetMapping("/profile/update")
    public String updateProfile(@RequestParam("userId") Integer userId, Model model) {
        // Get the current user info
        User user = userService.getUserById(userId);
        model.addAttribute("user", user);  // Add the user info to the model for form pre-filling
        return "updateProfile";  // Return the view for updating profile
    }

    // Display the update form (get the existing user details)
    @GetMapping("/updateProfileForm")
    public String showUpdateForm(@RequestParam("userId") Integer userId, Model model) {
        User user = userRepo.findById(userId).orElse(null);
        model.addAttribute("user", user);
        return "updateProfile";
    }

    // Send verification email for profile update
    @PostMapping("/sendVerificationEmail")
    @ResponseBody
    public Map<String,Object> sendVerificationEmail(@RequestBody User user) {
        userService.sendCodeConfirmationEmail(user);

        Map<String,Object> result = new HashMap<>();
        result.put("ok", true);
        return result;
    }

    // Update password after verification code
    @PostMapping("/updatePwd")
    public String updatePwd(@RequestBody User user, @RequestParam String newPassword) {
        userService.updatePwd(user, newPassword);
        return "redirect:/login";
    }

    // Display update password page
    @GetMapping("/updatePassword")
    public String updatePassword(@RequestParam("userId") Integer userId, Model model) {
        User user = userService.getUserById(userId);
        model.addAttribute("user", user);
        return "updatePassword";
    }

    // Handle the update profile form submission (post request to update user details)
    @PostMapping("/updateProfileForm")  // Changed route
    public String updateProfile(@RequestParam("userId") Integer userId,
                                @RequestParam("email") String email,
                                @RequestParam("avatar") String avatar,
                                Model model) {

        try {
            User existingUser = userService.getUserById(userId);
            existingUser.setEmail(email);
            existingUser.setAvatar(avatar);
            userService.updateUserInfo(userId, existingUser);
            model.addAttribute("user", existingUser);

            String token = generateTokenForUser(existingUser);

            AccountVerificationEmailContext emailContext = new AccountVerificationEmailContext();
            emailContext.init(existingUser);
            emailContext.setToken(token);
            emailContext.buildVerificationUrl("http://localhost:8080", token);

            emailService.sendMail(emailContext);
            return "redirect:/updateProfileSuccessPage";
        } catch (MessagingException e) {
            e.printStackTrace();
            return "error";
        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
    }

    // Display the success page after updating the profile
    @GetMapping("/updateProfileSuccessPage")
    public String showUpdateProfileSuccessPage() {
        return "updateProfileSuccess";
    }

    // Generate a unique token for the user
    private String generateTokenForUser(User user) {
        String token = java.util.UUID.randomUUID().toString();
        return token;
    }

    // Handle the confirmation URL after user clicks on the link in the email
    @GetMapping("/confirm-update")
    public String confirmUpdate(@RequestParam("token") String token) {
        try {
            boolean success = userService.verifyUser(token);
            if (success) {
                return "redirect:/updateProfileSuccessPage";
            } else {
                return "error";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
    }
}
