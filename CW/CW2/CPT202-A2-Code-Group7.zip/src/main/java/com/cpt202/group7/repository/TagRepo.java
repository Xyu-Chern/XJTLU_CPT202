package com.cpt202.group7.repository;

import com.cpt202.group7.model.Tag;
import com.cpt202.group7.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TagRepo extends JpaRepository<Tag, Integer> {
    List<Tag> findByUserAndStatus(User user, Integer status);
    Tag findByUserAndIdAndStatus(User user, Integer id, Integer status);
    List<Tag> findByUserAndStatusAndIdIn(User user, Integer status, List<Integer> ids);
}
