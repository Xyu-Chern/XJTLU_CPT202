package com.cpt202.group7.service;

import com.cpt202.group7.model.SecureToken;

public interface SecureTokenService {
    SecureToken createToken();
    void saveSecureToken(SecureToken secureToken);
    SecureToken findByToken(String token);
    void removeToken(SecureToken token);
    SecureToken findByTokenAndUserId(Integer userId, String code);
}
