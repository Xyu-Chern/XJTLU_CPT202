package com.cpt202.group7.exception;

public class UnknownIdentifierException extends Exception{
    public UnknownIdentifierException(String message) {
        super(message);
    }
}
