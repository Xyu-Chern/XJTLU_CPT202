package com.cpt202.group7.controller;

import com.cpt202.group7.model.Category;
import com.cpt202.group7.model.MusicResource;
import com.cpt202.group7.model.User;
import com.cpt202.group7.repository.CategoryRepo;
import com.cpt202.group7.repository.MusicResourceRepo;
import com.cpt202.group7.repository.TagRepo;
import com.cpt202.group7.repository.UserRepo;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@Controller
public class UploadController {

    @Autowired
    private MusicResourceRepo musicResourceRepo;
    @Autowired
    private UserRepo userRepo;
    @Autowired
    private CategoryRepo categoryRepo;

    @PostMapping("/tupload")
    public Object testUploading(String req) {

        return "OK";
    }

    @GetMapping("/upload")
    public String upload(HttpSession session, Model m) {
        User loginUser = (User) session.getAttribute("loginUser");
        m.addAttribute("categories", categoryRepo.findByUserAndStatus(loginUser, 0));
        return "upload";
    }

    @PostMapping("/upload")
    public String uploadMusic(@RequestParam("file") MultipartFile file,
                              MultipartFile coverImg,
                              MusicResource musicResource,
                              @RequestParam(required = false) Integer categoryId,
                              HttpSession session,
                              Model m) throws IOException {

        String fileName = System.currentTimeMillis() + file.getOriginalFilename();
        String imgName = System.currentTimeMillis() + coverImg.getOriginalFilename();

//            获取当前 Web 应用程序根目录在服务器文件系统中的真实物理路径，上传的具体位置
//            String dstFileName = req.getServletContext().getRealPath("") + "uploaded" + File.separator + fileName;
//            String dstFileName = req.getServletContext().getRealPath("") + "/music/" + fileName;
        String dstFileName = System.getProperty("user.dir") + "/music/" + fileName;
        String dstImgName = System.getProperty("user.dir") + "/img/" + imgName;

        File dstFile = new File(dstFileName);
        File dstImgFile = new File(dstImgName);

//            确保目标文件的父目录存在，若不存在则递归创建所有缺失的目录
        boolean result1 = dstFile.getParentFile().mkdirs();
        boolean result2 = dstImgFile.getParentFile().mkdirs();

//            将file转换成待创建的dstFile（文件保存并记录文件的最终路径）
        file.transferTo(dstFile);
        coverImg.transferTo(dstImgFile);
        if (result1 && result2) {
            m.addAttribute("fileName",fileName);
            m.addAttribute("message", "Upload Successfully");
        }

        User user = (User) session.getAttribute("loginUser");
        if (user != null) {
            user.setUploadCount(user.getUploadCount() + 1);
            userRepo.save(user);
            musicResource.setUser(user);
        }

        Category category = categoryRepo.findByUserAndIdAndStatus(user, categoryId, 0);
        if (category != null) {
            category.setVolume(category.getVolume() + 1);
            categoryRepo.save(category);
            musicResource.setCategory(category);
        }

        musicResource.setFileName(fileName);
        musicResource.setCover(imgName);
        musicResource.setStatus(1);
        musicResourceRepo.save(musicResource);


        return "redirect:/";
    }

}
