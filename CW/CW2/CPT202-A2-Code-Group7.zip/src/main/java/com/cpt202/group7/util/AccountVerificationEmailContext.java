package com.cpt202.group7.util;

import com.cpt202.group7.model.User;
import org.springframework.web.util.UriComponentsBuilder;

public class AccountVerificationEmailContext extends AbstractEmailContext{
    private String token;
    private String verificationURL;
    @Override
    public <T> void init(T context) {
        User user = (User) context;

        setTemplateLocation("emailVerification");
        setSubject("Complete your registration");
        setFrom("natalieY@126.com");
        setTo(user.getEmail());
        put("user", user);
    }




    public void setToken(String token) {
        this.token = token;
        put("token", this.token);
    }

    public void buildVerificationUrl(final String baseURL, final String token) {
        final String url = UriComponentsBuilder.fromHttpUrl(baseURL)
                .path("/register/verify").queryParam("token", token).toUriString();
        put("verificationURL", url);
    }
}
