package com.cpt202.group7.controller;

import com.cpt202.group7.model.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class FeedbackController {
    @GetMapping("/feedback")
    public String getFeedbackPage(HttpSession session) {
        User user = (User) session.getAttribute("loginUser");
        if (user.getRole() == 0) {
            return "redirect:/admin/profile";
        }
        return "redirect:/profile";
    }

    @PostMapping("/feedback")
    public String feedback(String message, String type, HttpSession session, Model m) {
        User user = (User) session.getAttribute("loginUser");
        if (user.getRole() == 0) {
            m.addAttribute("feedbackMessage", "Send feedback successfully");
            m.addAttribute("user", user);  // Add user information to the model
            m.addAttribute("avatar", user.getAvatar());
            return "profileAdminPage";
        }
        m.addAttribute("user", user);
        m.addAttribute("avatar", user.getAvatar());
        m.addAttribute("feedbackMessage", "Send feedback successfully");
        return "profilePage";
    }
}
