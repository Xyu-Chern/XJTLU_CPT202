package com.cpt202.group7.model;

import jakarta.persistence.*;
import lombok.Data;
import java.util.Set;


@Data
@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String email;
    private String password;
    private String avatar; // 头像Url
    private String name;
    private Integer role; // 0管理员  1用户
    private Integer status; // 0已验证 1未验证 2封禁中
    private Integer uploadCount;
    private Integer banCount;
    @OneToMany(mappedBy = "user")
    private Set<SecureToken> token;
}
