package com.cpt202.group7.controller;

import com.cpt202.group7.model.Category;
import com.cpt202.group7.model.MusicResource;
import com.cpt202.group7.model.Tag;
import com.cpt202.group7.model.User;
import com.cpt202.group7.repository.CategoryRepo;
import com.cpt202.group7.repository.MusicResourceRepo;
import com.cpt202.group7.repository.TagRepo;
import com.cpt202.group7.service.MusicResourceService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;

@Controller
public class MusicResourceController {

    @Autowired
    private MusicResourceRepo musicResourceRepo;

    @Autowired
    private CategoryRepo categoryRepo;

    @Autowired
    private TagRepo tagRepo;

    @PostMapping("/music/edit")
    public String editMusicResource(Integer id,
                                    @RequestParam(required = false) Integer categoryId,
                                    @RequestParam(required = false) List<Integer> tagIds,
                                    HttpSession session,
                                    Model m) {
        User loginUser = (User) session.getAttribute("loginUser");
        MusicResource musicResource = musicResourceRepo.findByUserAndIdAndStatus(loginUser, id, 0);
        if (musicResource == null) {
            m.addAttribute("error", "Music Resource Not Found.");
            return "redirect:/";
        }
        Category oldCategory = musicResource.getCategory();
        if (oldCategory != null) {
            oldCategory.setVolume(oldCategory.getVolume() - 1);
            categoryRepo.save(oldCategory);
        }
        Category newCategory = categoryRepo.findByUserAndIdAndStatus(loginUser, categoryId, 0);
        if (newCategory != null) {
            newCategory.setVolume(newCategory.getVolume() + 1);
            categoryRepo.save(newCategory);
            musicResource.setCategory(newCategory);
        }
        List<Tag> oldTags = musicResource.getTags();
        if (!CollectionUtils.isEmpty(oldTags)) {
            for (Tag oldTag : oldTags) {
                oldTag.setVolume(oldTag.getVolume() - 1);
                tagRepo.save(oldTag);
            }
        }
        List<Tag> newTags = tagRepo.findByUserAndStatusAndIdIn(loginUser, 0, tagIds);
        if (!CollectionUtils.isEmpty(newTags)) {
            for (Tag newTag : newTags) {
                newTag.setVolume(newTag.getVolume() + 1);
                tagRepo.save(newTag);
                musicResource.setTags(newTags);
            }
        }
        musicResourceRepo.save(musicResource);
        return "redirect:/";
    }


}
