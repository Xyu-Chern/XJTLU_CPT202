package com.cpt202.group7.controller;

import com.cpt202.group7.model.Category;
import com.cpt202.group7.model.MusicResource;
import com.cpt202.group7.model.Tag;
import com.cpt202.group7.model.User;
import com.cpt202.group7.repository.CategoryRepo;
import com.cpt202.group7.repository.MusicResourceRepo;
import com.cpt202.group7.repository.TagRepo;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Controller
public class TagController {

    @Autowired
    private TagRepo tagRepo;

    @Autowired
    private MusicResourceRepo musicResourceRepo;

    @GetMapping("/tag")
    public String getAllTags(HttpSession session, Model m) {
        User loginUser = (User) session.getAttribute("loginUser");
        m.addAttribute("avatar", loginUser.getAvatar());
        m.addAttribute("tags", tagRepo.findByUserAndStatus(loginUser, 0));
        return "tag";
    }

    @PostMapping("/tag/add")
    public String addTag(Tag tag, HttpSession session, Model m) {
        tag.setStatus(0);
        tag.setVolume(0);
        User loginUser = (User) session.getAttribute("loginUser");
        tag.setUser(loginUser);
        tagRepo.save(tag);
        m.addAttribute("message", "Add tag successfully.");
        return "redirect:/tag";
    }

    @PostMapping("/tag/edit")
    public String editTag(Tag tag, HttpSession session, Model m) {
        User loginUser = (User) session.getAttribute("loginUser");
        Tag tag2 = tagRepo.findByUserAndIdAndStatus(loginUser, tag.getId(), 0);
        tag2.setName(tag.getName());
        tagRepo.save(tag2);
        m.addAttribute("message", "Edit tag successfully.");
        return "redirect:/tag";
    }

    @PostMapping("/tag/delete")
    public String deleteTag(Integer id, HttpSession session, Model m) {
        User loginUser = (User) session.getAttribute("loginUser");
        Tag tag = tagRepo.findByUserAndIdAndStatus(loginUser, id, 0);
        List<Tag> singleTagSet = new ArrayList<>();
        singleTagSet.add(tag);
        List<MusicResource> musicResources = musicResourceRepo.findByUserAndStatusAndTagsIn(loginUser, 0, singleTagSet);
        for (MusicResource mr : musicResources) {
            List<Tag> tags = mr.getTags();
            tags.remove(tag);
            mr.setTags(tags);
            musicResourceRepo.save(mr);
        }
        tag.setVolume(0);
        tag.setStatus(3);
        tagRepo.save(tag);
        return "redirect:/tag";
    }
}
