package com.cpt202.group7.service.impl;

import com.cpt202.group7.model.SecureToken;
import com.cpt202.group7.repository.SecureTokenRepo;
import com.cpt202.group7.service.SecureTokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.keygen.BytesKeyGenerator;
import org.springframework.security.crypto.keygen.KeyGenerators;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

@Service
public class SecureTokenServiceImpl implements SecureTokenService {

    private static final int TOKEN_SIZE = 12;
    private static final int tokenValidityInSeconds = 86400; // 24小时的有效期

    private final SecureTokenRepo secureTokenRepo;

    @Autowired
    public SecureTokenServiceImpl(SecureTokenRepo secureTokenRepository) {
        this.secureTokenRepo = secureTokenRepository;
    }

    @Override
    public SecureToken createToken() {
        BytesKeyGenerator tokenGenerator = KeyGenerators.secureRandom(TOKEN_SIZE); // Use secureRandom key generator
        byte[] tokenBytes = tokenGenerator.generateKey(); // Generate a secure random key

        String tokenValue = Base64.getUrlEncoder().encodeToString(tokenBytes); // Use URL-safe Base64 encoding
        SecureToken secureToken = new SecureToken();
        secureToken.setToken(tokenValue);  // Set the generated token value
        secureToken.setExpiredDate(LocalDateTime.now().plusSeconds(tokenValidityInSeconds)); // Set expiration time (24 hours)
        return secureToken;
    }

    @Override
    public void saveSecureToken(SecureToken secureToken) {
        secureTokenRepo.save(secureToken); // Save token to the database
    }

    @Override
    public SecureToken findByToken(String token) {
        return secureTokenRepo.findByToken(token); // Find SecureToken by token value
    }

    @Override
    public void removeToken(SecureToken token) {
        secureTokenRepo.delete(token); // Delete the specified token
    }

    @Override
    public SecureToken findByTokenAndUserId(Integer userId, String code) {
        // Find SecureToken list by userId
        List<SecureToken> result = secureTokenRepo.findByUserId(userId);
        if (CollectionUtils.isEmpty(result)) {
            return null;  // Return null if no tokens are found
        }

        // Stream to find the first matching token (not used and matches code)
        Optional<SecureToken> first = result.stream()
                .filter(row -> !row.isUsed() && row.getToken().equals(code)) // Filter out unused tokens matching the provided code
                .findFirst();

        return first.orElse(null); // Return the first matching token, or null if not found
    }
}
