package com.cpt202.group7.controller;

import com.cpt202.group7.model.Category;
import com.cpt202.group7.model.MusicResource;
import com.cpt202.group7.model.Tag;
import com.cpt202.group7.model.User;
import com.cpt202.group7.repository.CategoryRepo;
import com.cpt202.group7.repository.MusicResourceRepo;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
public class CategoryController {

    @Autowired
    private CategoryRepo categoryRepo;

    @Autowired
    private MusicResourceRepo musicResourceRepo;

    @GetMapping("/category")
    public String getAllCategories(HttpSession session, Model m) {
        User loginUser = (User) session.getAttribute("loginUser");
        m.addAttribute("avatar", loginUser.getAvatar());
        m.addAttribute("categories", categoryRepo.findByUserAndStatus(loginUser,0));
        return "category2";
    }

    @PostMapping("/category/add")
    public String addCategory(Category category, HttpSession session, Model m) {
        category.setStatus(0);
        category.setVolume(0);
        User user = (User) session.getAttribute("loginUser");
        category.setUser(user);
        categoryRepo.save(category);
        m.addAttribute("message", "Add category successfully.");
        return "redirect:/category";
    }

    @PostMapping("/category/edit")
    public String editCategory(Category category, HttpSession session, Model m) {
        User loginUser = (User) session.getAttribute("loginUser");
        Category category2 = categoryRepo.findByUserAndIdAndStatus(loginUser, category.getId(), 0);
        category2.setName(category.getName());
        categoryRepo.save(category2);
        m.addAttribute("message", "Edit category successfully.");
        return "redirect:/category";
    }

    @PostMapping("/category/delete")
    public String deleteCategory(Integer id, HttpSession session, Model m) {
        User loginUser = (User) session.getAttribute("loginUser");
        Category category = categoryRepo.findByUserAndIdAndStatus(loginUser, id, 0);
        List<MusicResource> musicResources = musicResourceRepo.findByUserAndStatusAndCategory(loginUser, 0, category);
        for (MusicResource mr : musicResources) {
            mr.setCategory(null);
            musicResourceRepo.save(mr);
        }
        category.setVolume(0);
        category.setStatus(3);
        categoryRepo.save(category);
        return "redirect:/category";
    }
}
