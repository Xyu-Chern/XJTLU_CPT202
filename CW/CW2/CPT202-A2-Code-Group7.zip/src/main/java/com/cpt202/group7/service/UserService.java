package com.cpt202.group7.service;

import com.cpt202.group7.exception.InvalidTokenException;
import com.cpt202.group7.exception.UserAlreadyActivatedException;
import com.cpt202.group7.model.User;
import org.springframework.web.multipart.MultipartFile;

public interface UserService {

    // Register a user with an avatar file
    void register(User user, MultipartFile avatarFile);

    // Upload avatar file separately
    void uploadAvatarFile(User user, MultipartFile avatarFile);

    // Send registration confirmation email
    void sendRegistrationConfirmationEmail(User user);

    // Send verification code email for user
    void sendCodeConfirmationEmail(User user);

    // Verify user by token
    boolean verifyUser(String token) throws InvalidTokenException, UserAlreadyActivatedException;

    // Update user information by userId
    void updateUserInfo(Integer userId, User updatedUser);

    // Get user by ID
    User getUserById(Integer userId);

    // Update user password
    void updatePwd(User user, String code);
}
