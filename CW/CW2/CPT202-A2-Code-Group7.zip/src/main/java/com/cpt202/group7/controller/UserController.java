package com.cpt202.group7.controller;

import com.cpt202.group7.exception.InvalidTokenException;
import com.cpt202.group7.exception.UserAlreadyActivatedException;
import com.cpt202.group7.model.User;
import com.cpt202.group7.repository.UserRepo;
import com.cpt202.group7.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.thymeleaf.util.StringUtils;

@Controller
public class UserController {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private UserService userService;

    private BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(12);

    // Register Page - GET request
    @GetMapping("/register")
    public String getRegisterPage(Model m) {
        m.addAttribute("user", new User());
        return "registerPage";
    }

    // Register Page - POST request with avatar upload
    @PostMapping("/register")
    public String postRegisterPage(@ModelAttribute User user,
                                   @RequestParam(value = "avatarFile", required = false) MultipartFile avatarFile,
                                   String confirmPassword,
                                   Model m) {
        // Check if the email and password fields are empty
        if (StringUtils.isEmpty(user.getEmail()) || StringUtils.isEmpty(user.getPassword())) {
            m.addAttribute("error", "Email and password are required");
            return "registerPage";
        }

        // Validate email format
        String email = user.getEmail();
        String emailPattern = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
        if (!email.matches(emailPattern)) {
            m.addAttribute("error", "Invalid email format");
            return "registerPage";
        }

        // Validate password strength: at least 8 characters, one number, and one special character
        String password = user.getPassword();
        String passwordPattern = "^(?=.*[0-9])(?=.*[!@#$%^&*])[A-Za-z0-9!@#$%^&*]{8,}$";
        if (!password.matches(passwordPattern)) {
            m.addAttribute("error", "Password must be at least 8 characters long, contain at least one number, and one special character");
            return "registerPage";
        }

        // Check if the email is already registered
        User existingUser = userRepo.findByEmail(user.getEmail());
        if (existingUser != null) {
            m.addAttribute("error", "Email already registered");
            return "registerPage";
        }

        if (!confirmPassword.equals(password)) {
            m.addAttribute("error", "Confirm Password Incorrect");
            return "registerPage";
        }

        // If avatar file is provided, save it
        userService.register(user, avatarFile); // Save user and avatar

        m.addAttribute("avatar", user.getAvatar());
        m.addAttribute("message", "Registration successful. Please check your email for the activation link.");
        return "registerPage";
    }

    // Account verification
    @GetMapping("/register/verify")
    public String verifyUser(@RequestParam("token") String token, Model model) {
        if (StringUtils.isEmpty(token)) {
            model.addAttribute("error", "Invalid token");
            return "verificationResult";
        }
        try {
            userService.verifyUser(token);
            model.addAttribute("message", "Account verified successfully");
        } catch (UserAlreadyActivatedException e) {
            e.printStackTrace();
            model.addAttribute("error", "User already activated");
        } catch (InvalidTokenException e) {
            e.printStackTrace();
            model.addAttribute("error", "Invalid verification token");
        }
        return "verificationResult";
    }

    // Login Page - GET request
    @GetMapping("/login")
    public String getLoginPage(Model m) {
        m.addAttribute("user", new User());
        return "login2";
    }

    // Login Page - POST request
    @PostMapping("/login")
    public String postLoginPage(@ModelAttribute User user, Model m, HttpSession session) {
        User existingUser = userRepo.findByEmail(user.getEmail());
        if (existingUser != null && encoder.matches(user.getPassword(), existingUser.getPassword()) && existingUser.getRole() == 1 && existingUser.getStatus() == 0){
            // login success
            session.setAttribute("loginUser", existingUser);
            return "redirect:/";
        } if (existingUser != null && encoder.matches(user.getPassword(), existingUser.getPassword()) && existingUser.getRole() == 0){
            // login success
            session.setAttribute("loginUser", existingUser);
            return "redirect:/admin/audit";
        } else if (existingUser != null && existingUser.getStatus() == 1) {
            m.addAttribute("error", "Account not activated. Please check your email for the activation link.");
            return "login2";
        } else if (existingUser != null && existingUser.getStatus() == 2) {
            m.addAttribute("error", "Account is banned. Please seek help from administrator.");
            return "login2";
        } else {
            m.addAttribute("error", "Invalid email or password");
            return "login2";
        }
    }

    // Get User Avatar (for profile)
    @GetMapping("/getAvatar")
    @ResponseBody
    public String getAvatar(@RequestParam("email") String email) {
        User user = userRepo.findByEmail(email);
        if (user != null && user.getAvatar() != null) {
            return "/img/" + user.getAvatar(); // Return avatar path
        }
        return "/img/default-avatar.jpg"; // Return default avatar path
    }

    @RequestMapping("/logout")
    public String logout(HttpSession session) {
        session.removeAttribute("loginUser");
        return "redirect:/login";
    }

}
