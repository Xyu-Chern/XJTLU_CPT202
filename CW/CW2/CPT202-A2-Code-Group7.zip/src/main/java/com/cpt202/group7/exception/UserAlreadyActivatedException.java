package com.cpt202.group7.exception;

public class UserAlreadyActivatedException extends Exception{
    public UserAlreadyActivatedException(String message) {
        super(message);
    }
}
