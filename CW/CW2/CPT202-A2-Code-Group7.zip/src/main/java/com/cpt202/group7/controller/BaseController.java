package com.cpt202.group7.controller;

import com.cpt202.group7.model.Category;
import com.cpt202.group7.model.Tag;
import com.cpt202.group7.model.User;
import com.cpt202.group7.repository.CategoryRepo;
import com.cpt202.group7.repository.MusicResourceRepo;
import com.cpt202.group7.repository.TagRepo;
import io.micrometer.core.instrument.Tags;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Controller
public class BaseController {

    @Autowired
    private MusicResourceRepo musicResourceRepo;

    @Autowired
    private CategoryRepo categoryRepo;

    @Autowired
    private TagRepo tagRepo;

    @GetMapping("/")
    public String getAllMusicResources(HttpSession session, Model m) {
        User loginUser = (User) session.getAttribute("loginUser");
        if (loginUser.getRole() == 0) {
            return "redirect:/admin/audit";
        }
        m.addAttribute("avatar", loginUser.getAvatar());
        m.addAttribute("result", musicResourceRepo.findByUserAndStatus(loginUser, 0));
        m.addAttribute("categories", categoryRepo.findByUserAndStatus(loginUser, 0));
        m.addAttribute("tags", tagRepo.findByUserAndStatus(loginUser, 0));
        return "index2";
    }

    @GetMapping("/error")
    public String error(HttpServletRequest request, Model m) {
        m.addAttribute("status", request.getAttribute("status"));
        m.addAttribute("message",request.getAttribute("message"));
        m.addAttribute("timestamp", request.getAttribute("timestamp"));
        m.addAttribute("path", request.getAttribute("path"));
        m.addAttribute("error", request.getAttribute("error"));
        return "error";
    }

}
