package com.cpt202.group7.repository;

import com.cpt202.group7.model.SecureToken;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SecureTokenRepo extends JpaRepository<SecureToken, Integer> {
    SecureToken findByToken(final String token);
    List<SecureToken> findByUserId(final Integer userId);
}
