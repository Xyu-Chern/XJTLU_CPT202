const { createApp } = Vue;

createApp({
    data() {
        return {
            sidebarOpen: true,
            searchQuery: '',
            isDark: true,
            user: {
                avatar: null,
                username: '',
                email: ''
            },
            showUploadModal: false,
            showCategoryModal: false,
            showTagModal: false,
            showDeleteModal: false,
            uploadForm: {
                title: '',
                artist: '',
                album: ''
            },
            categoryForm: {
                name: '',
                description: ''
            },
            tagForm: {
                name: '',
                description: ''
            },
            editingCategory: null,
            editingTag: null,
            deleteItemId: null,
            deleteType: null,
            currentTrack: {
                id: 1,
                title: '富士山下',
                artist: '陈奕迅',
                album: 'What\'s Going On...?',
                cover: '/img/富士山下.png',
                isPlaying: false,
                audio: null,
                duration: 0,
                currentTime: 0,
                volume: 0.5
            },
        }
    },
    methods: {
        toggleSidebar() {
            this.sidebarOpen = !this.sidebarOpen;
        },
        handleSearch() {
            clearTimeout(this.searchTimeout);
            this.searchTimeout = setTimeout(() => {
                fetch(`/search?query=${encodeURIComponent(this.searchQuery)}`)
                    .then(response => response.json())
                    .then(data => {
                        console.log('Search results:', data);
                    })
                    .catch(error => {
                        console.error('Search error:', error);
                    });
            }, 300);
        },
        toggleTheme() {
            this.isDark = !this.isDark;
            document.documentElement.setAttribute('data-theme', this.isDark ? 'dark' : 'light');
        },
        handleAvatarUpload(event) {
            const file = event.target.files[0];
            if (file) {
                const formData = new FormData();
                formData.append('avatar', file);

                fetch('/updateProfile', {
                    method: 'POST',
                    body: formData
                })
                    .then(response => response.json())
                    .then(data => {
                        this.user.avatar = data.avatarUrl;
                    })
                    .catch(error => {
                        console.error('Avatar upload error:', error);
                    });
            }
        },
        openCategoryModal() {
            this.showCategoryModal = true;
            this.categoryForm = { name: '', description: '' };
            this.editingCategory = null;
        },
        closeCategoryModal() {
            this.showCategoryModal = false;
            this.categoryForm = { name: '', description: '' };
            this.editingCategory = null;
        },
        editCategory(category) {
            this.editingCategory = category;
            this.categoryForm = { ...category };
            this.showCategoryModal = true;
        },
        deleteCategory(id) {
            this.deleteItemId = id;
            this.deleteType = 'category';
            this.showDeleteModal = true;
        },
        handleCategorySubmit() {
            const url = this.editingCategory
                ? `/api/categories/${this.editingCategory.id}`
                : '/api/categories';

            const method = this.editingCategory ? 'PUT' : 'POST';

            fetch(url, {
                method: method,
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(this.categoryForm)
            })
                .then(response => response.json())
                .then(() => {
                    this.closeCategoryModal();
                    window.location.reload();
                })
                .catch(error => {
                    console.error('Category save error:', error);
                });
        },
        openTagModal() {
            this.showTagModal = true;
            this.tagForm = { name: '', description: '' };
            this.editingTag = null;
        },
        closeTagModal() {
            this.showTagModal = false;
            this.tagForm = { name: '', description: '' };
            this.editingTag = null;
        },
        editTag(tag) {
            this.editingTag = tag;
            this.tagForm = { ...tag };
            this.showTagModal = true;
        },
        deleteTag(id) {
            this.deleteItemId = id;
            this.deleteType = 'tag';
            this.showDeleteModal = true;
        },
        handleTagSubmit() {
            const url = this.editingTag
                ? `/api/tags/${this.editingTag.id}`
                : '/api/tags';

            const method = this.editingTag ? 'PUT' : 'POST';

            fetch(url, {
                method: method,
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(this.tagForm)
            })
                .then(response => response.json())
                .then(() => {
                    this.closeTagModal();
                    window.location.reload();
                })
                .catch(error => {
                    console.error('Tag save error:', error);
                });
        },
        closeDeleteModal() {
            this.showDeleteModal = false;
            this.deleteItemId = null;
            this.deleteType = null;
        },
        confirmDelete() {
            if (!this.deleteItemId || !this.deleteType) return;

            const url = `/${this.deleteType}/delete`;

            fetch(url, {
                method: 'POST'
            })
                .then(() => {
                    this.closeDeleteModal();
                    window.location.reload();
                })
                .catch(error => {
                    console.error('Delete error:', error);
                });
        },
        handleFileUpload(event) {
            const file = event.target.files[0];
            if (file) {
                const filePreview = document.getElementById('filePreview');
                const fileName = document.querySelector('.file-name');
                const fileSize = document.querySelector('.file-size');

                fileName.textContent = file.name;
                fileSize.textContent = `${(file.size / (1024 * 1024)).toFixed(2)} MB`;
                filePreview.style.display = 'block';
            }
        },
        removeFile() {
            const fileInput = document.getElementById('musicFile');
            const filePreview = document.getElementById('filePreview');

            fileInput.value = '';
            filePreview.style.display = 'none';
        }
    },
    mounted() {
        document.documentElement.setAttribute('data-theme', this.isDark ? 'dark' : 'light');

        // File upload handling
        const fileInput = document.getElementById('musicFile');
        const fileDropArea = document.getElementById('fileDropArea');

        if (fileDropArea) {
            ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
                fileDropArea.addEventListener(eventName, (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                });
            });

            fileDropArea.addEventListener('dragenter', () => {
                fileDropArea.classList.add('drag-over');
            });

            fileDropArea.addEventListener('dragleave', () => {
                fileDropArea.classList.remove('drag-over');
            });

            fileDropArea.addEventListener('drop', (e) => {
                fileDropArea.classList.remove('drag-over');
                const file = e.dataTransfer.files[0];
                if (file) {
                    fileInput.files = e.dataTransfer.files;
                    this.handleFileUpload({ target: { files: [file] } });
                }
            });
        }
    }
}).mount('#app');
